#!/bin/sh
# W7：抓課程核心套件並核對 SHA256（在教室電腦跑；要有 curl 與 sha256sum）
# 出處：apt-repo.arduino.cc stable（2026-10-21 讀）；SHA256 來自同一份 Packages 索引
set -e
F=linux-image-7.0.0-g122c2c22d838_7.0.0-g122c2c22d838-1_arm64.deb
URL="https://apt-repo.arduino.cc/pool/main/l/linux-upstream/$F"
SHA=fb878aa55e3d3fa05f439c8b6f395749e5177c4c15eaea5f0be415678e26f183
[ -f "$F" ] || curl -LO "$URL"
GOT=$(sha256sum "$F" | cut -d' ' -f1)
if [ "$GOT" = "$SHA" ]; then
  echo "OK  $F  sha256 相符（33792024 bytes）"
else
  echo "FAIL  sha256 不符：拿到 $GOT"; echo "→ 刪掉 $F 重抓；還是不符就舉手，用老師隨身碟的那份"; exit 1
fi
