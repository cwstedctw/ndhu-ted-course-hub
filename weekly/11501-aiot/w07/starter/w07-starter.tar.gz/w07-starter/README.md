# w07-starter：換核心不拆板（AIoT W7，2026-10-22）

| 檔 | 用途 | 核對 |
|---|---|---|
| `get-kernel.sh` | 在教室電腦抓課程核心套件 `linux-image-7.0.0-g122c2c22d838_…_arm64.deb`（33,792,024 bytes）並核對 SHA256 `fb878aa5…26f183` | 印 `OK` 才往下 |
| `uac2-soundcard/u_audio.ko` | USB 音效卡模組之一，只配核心 `7.0.0-g122c2c22d838` | SHA256 `6c90c70d8cd54db8593ba2d74ce9b0e695a182bd2fca2724c50d390f83dcbdd3` |
| `uac2-soundcard/usb_f_uac2.ko` | 同上 | SHA256 `5c955ddd1414c1db13acfbf19c26911326683b7a535df4e1e28efc31d6d26f6a` |
| `health_ble.py` | 第三節：板子的藍牙健康手環服務（BlueZ＋python3-gi，不用裝套件）；推上板後 `python3 ~/health_ble.py --name UNOQ-G03A` | md5 `d7cb10f6032ce99437151dcc62d99ceb`（LF） |

模組要放到板子的 `/home/arduino/uac2-soundcard/`（W6 裝的 hook 只認這個路徑）。兩個 `.ko` 是 GPL 核心模組，從課程測試場 `arduino-q/labs/w01-same-board/assets/uac2/7.0.0-g122c2c22d838/` 原樣複製。
核心套件本身不放在這包（34 MB），用 `get-kernel.sh` 抓，或向老師拿隨身碟那份。
