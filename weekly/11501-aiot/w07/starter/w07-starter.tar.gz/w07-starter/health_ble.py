#!/usr/bin/env python3
"""UNO Q 健康手環：用 BlueZ 開一個 BLE 服務，把板況每秒送到手機。

只用板上現成的 python3-gi（GLib／Gio），不裝任何套件、不用 sudo（arduino 在 bluetooth 群組）。
協定＝Nordic UART Service（NUS）：
  Service 6E400001-B5A3-F393-E0A9-E50E24DCCA9E
  RX      6E400002-…  手機 write 進來（指令，只收 allowlist）
  TX      6E400003-…  板子 notify 出去（每秒一行板況 CSV）
手機端：Adafruit Bluefruit Connect（UART／Plotter）或 nRF Connect。

用法：python3 health_ble.py [--name UNOQ-XX] [--period 1.0]
"""
import argparse
import os
import re
import socket
import subprocess
import sys
import time

from gi.repository import Gio, GLib

BLUEZ = "org.bluez"
ADAPTER = "/org/bluez/hci0"
NUS_SVC = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
NUS_RX = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
NUS_TX = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
APP_PATH = "/tw/ndhu/unoq/health"
SVC_PATH = APP_PATH + "/svc0"
RX_PATH = SVC_PATH + "/rx"
TX_PATH = SVC_PATH + "/tx"
ADV_PATH = "/tw/ndhu/unoq/adv0"
MFG_ID = 0xFFFF  # 測試用公司代碼

# ---------------------------------------------------------------- 板況
def _read(path, default=""):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def _run(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=3).stdout
    except Exception:
        return ""


def cpu_temp_c():
    for z in sorted(os.listdir("/sys/class/thermal")):
        if not z.startswith("thermal_zone"):
            continue
        if _read(f"/sys/class/thermal/{z}/type") == "cpuss0-thermal":
            return int(_read(f"/sys/class/thermal/{z}/temp", "0")) / 1000.0
    return int(_read("/sys/class/thermal/thermal_zone0/temp", "0")) / 1000.0


def mem_used_pct():
    info = {}
    for line in _read("/proc/meminfo").splitlines():
        k, v = line.split(":", 1)
        info[k] = int(v.strip().split()[0])
    total = info.get("MemTotal", 1)
    avail = info.get("MemAvailable", 0)
    return round(100.0 * (total - avail) / total, 1)


def disk_used_pct():
    st = os.statvfs("/")
    total = st.f_blocks * st.f_frsize
    free = st.f_bavail * st.f_frsize
    return round(100.0 * (total - free) / total, 1)


def wifi_rssi():
    """UNO Q 映像沒有 iw，用 nmcli 讀目前連線的訊號強度（0–100%）。"""
    for line in _run(["nmcli", "-t", "-f", "IN-USE,SIGNAL", "dev", "wifi"]).splitlines():
        if line.startswith("*"):
            try:
                return int(line.split(":")[1])
            except (IndexError, ValueError):
                return 0
    return 0


def uptime_s():
    return int(float(_read("/proc/uptime", "0 0").split()[0]))


def containers_running():
    out = _run(["docker", "ps", "-q"])
    return len([l for l in out.splitlines() if l.strip()])


def health_line():
    load1 = float(_read("/proc/loadavg", "0").split()[0])
    return "T=%.1f L=%.2f M=%.0f D=%.0f W=%d U=%d C=%d" % (
        cpu_temp_c(), load1, mem_used_pct(), disk_used_pct(),
        wifi_rssi(), uptime_s(), containers_running())


PLOT_FIELDS = ["temp", "load", "mem", "disk", "wifi"]  # Plotter 的線順序（App 沒有標籤功能，只能靠順序對照）
PLOT_SEL = list(PLOT_FIELDS)  # 手機打 plot temp／plot all 可以改


def plot_values():
    load1 = float(_read("/proc/loadavg", "0").split()[0])
    return {"temp": "%.1f" % cpu_temp_c(), "load": "%.2f" % load1, "mem": "%.0f" % mem_used_pct(),
            "disk": "%.0f" % disk_used_pct(), "wifi": "%d" % wifi_rssi()}


def plot_line():
    """每秒推給手機的那行：純數字、逗號分隔，Bluefruit Connect 的 Plotter 才畫得出來。
    預設順序＝溫度°C, 負載, 記憶體%, 硬碟%, Wi-Fi%（打 health 會回帶標籤的版本）。"""
    v = plot_values()
    return ",".join(v[k] for k in PLOT_SEL)


def health_bytes():
    """廣播用：7 bytes 塞進 manufacturer data（溫度×10、負載×10、記憶體%、容器數、uptime 分鐘）。"""
    t = int(cpu_temp_c() * 10) & 0xFFFF
    l = int(float(_read("/proc/loadavg", "0").split()[0]) * 10) & 0xFF
    m = int(mem_used_pct()) & 0xFF
    c = containers_running() & 0xFF
    up = (uptime_s() // 60) & 0xFFFF
    return bytes([t & 0xFF, t >> 8, l, m, c, up & 0xFF, up >> 8])


# ---------------------------------------------------------------- 指令（allowlist）
def handle_command(text):
    cmd = text.strip().lower()
    if cmd in ("hi", "hello", "whoami"):
        return "I am %s (UNO Q)" % socket.gethostname()
    if cmd == "health":
        return health_line()
    if cmd == "uptime":
        return _run(["uptime"]).strip()
    if cmd == "ip":
        return " ".join(l.split()[2] for l in _run(["ip", "-4", "-br", "addr"]).splitlines()
                        if len(l.split()) > 2 and not l.startswith("lo"))
    if cmd == "apps":
        return _run(["docker", "ps", "--format", "{{.Names}}"]).replace("\n", ",").strip(",") or "none"
    if cmd.startswith("plot"):
        want = cmd.split()[1:] or ["all"]
        if want == ["all"]:
            PLOT_SEL[:] = PLOT_FIELDS
        else:
            bad = [w for w in want if w not in PLOT_FIELDS]
            if bad:
                return "plot: unknown %s (use %s|all)" % (",".join(bad), "|".join(PLOT_FIELDS))
            PLOT_SEL[:] = want
        return "plot order: " + ",".join(PLOT_SEL)
    if cmd == "help":
        return "hi|health|uptime|ip|apps|plot <temp|load|mem|disk|wifi|all>|help ; plot order now: " + ",".join(PLOT_SEL)
    return "unknown: %r (try help)" % text[:20]


# ---------------------------------------------------------------- D-Bus 介面定義
INTROSPECT_XML = """
<node>
  <interface name="org.freedesktop.DBus.ObjectManager">
    <method name="GetManagedObjects">
      <arg type="a{oa{sa{sv}}}" name="objects" direction="out"/>
    </method>
  </interface>
  <interface name="org.bluez.GattService1">
    <property name="UUID" type="s" access="read"/>
    <property name="Primary" type="b" access="read"/>
  </interface>
  <interface name="org.bluez.GattCharacteristic1">
    <method name="ReadValue">
      <arg type="a{sv}" name="options" direction="in"/>
      <arg type="ay" name="value" direction="out"/>
    </method>
    <method name="WriteValue">
      <arg type="ay" name="value" direction="in"/>
      <arg type="a{sv}" name="options" direction="in"/>
    </method>
    <method name="StartNotify"/>
    <method name="StopNotify"/>
    <property name="UUID" type="s" access="read"/>
    <property name="Service" type="o" access="read"/>
    <property name="Flags" type="as" access="read"/>
    <property name="Value" type="ay" access="read"/>
    <property name="Notifying" type="b" access="read"/>
  </interface>
  <interface name="org.bluez.LEAdvertisement1">
    <method name="Release"/>
    <property name="Type" type="s" access="read"/>
    <property name="ServiceUUIDs" type="as" access="read"/>
    <property name="LocalName" type="s" access="read"/>
    <property name="ManufacturerData" type="a{qv}" access="read"/>
    <property name="Includes" type="as" access="read"/>
  </interface>
</node>
"""
NODE = Gio.DBusNodeInfo.new_for_xml(INTROSPECT_XML)
IFACE = {i.name: i for i in NODE.interfaces}


class HealthServer:
    def __init__(self, bus, name, period, mfg=True):
        self.bus = bus
        self.name = name
        self.period = period
        self.mfg = mfg
        self.notifying = False
        self.last_tx = b""
        self.reg_ids = []
        self.n_sent = 0

    # ---- 屬性表（BlueZ 會用 GetManagedObjects 跟 Properties.Get 來讀）
    def props(self, path, iface):
        if path == SVC_PATH and iface == "org.bluez.GattService1":
            return {"UUID": GLib.Variant("s", NUS_SVC), "Primary": GLib.Variant("b", True)}
        if path == TX_PATH and iface == "org.bluez.GattCharacteristic1":
            return {"UUID": GLib.Variant("s", NUS_TX), "Service": GLib.Variant("o", SVC_PATH),
                    "Flags": GLib.Variant("as", ["read", "notify"]),
                    "Value": GLib.Variant("ay", self.last_tx),
                    "Notifying": GLib.Variant("b", self.notifying)}
        if path == RX_PATH and iface == "org.bluez.GattCharacteristic1":
            return {"UUID": GLib.Variant("s", NUS_RX), "Service": GLib.Variant("o", SVC_PATH),
                    "Flags": GLib.Variant("as", ["write", "write-without-response"]),
                    "Value": GLib.Variant("ay", b""), "Notifying": GLib.Variant("b", False)}
        if path == ADV_PATH and iface == "org.bluez.LEAdvertisement1":
            return {"Type": GLib.Variant("s", "peripheral"),
                    "ServiceUUIDs": GLib.Variant("as", [NUS_SVC]),
                    "LocalName": GLib.Variant("s", self.name),
                    "ManufacturerData": GLib.Variant("a{qv}", {MFG_ID: GLib.Variant("ay", health_bytes())}) if self.mfg else GLib.Variant("a{qv}", {}),
                    "Includes": GLib.Variant("as", [])}
        return None

    def on_get_property(self, conn, sender, path, iface, prop):
        p = self.props(path, iface)
        if p is None or prop not in p:
            return None
        return p[prop]

    def on_method(self, conn, sender, path, iface, method, params, inv):
        try:
            if iface == "org.freedesktop.DBus.ObjectManager" and method == "GetManagedObjects":
                objs = {}
                for p, i in ((SVC_PATH, "org.bluez.GattService1"),
                             (TX_PATH, "org.bluez.GattCharacteristic1"),
                             (RX_PATH, "org.bluez.GattCharacteristic1")):
                    objs[p] = {i: self.props(p, i)}
                inv.return_value(GLib.Variant("(a{oa{sa{sv}}})", (objs,)))
            elif iface == "org.bluez.GattCharacteristic1":
                if method == "ReadValue" and path == TX_PATH:
                    v = health_line().encode()
                    inv.return_value(GLib.Variant("(ay)", (v,)))
                elif method == "WriteValue" and path == RX_PATH:
                    raw = bytes(params.get_child_value(0))
                    text = raw.decode("utf-8", "replace")
                    log("RX  <- %r" % text)
                    reply = handle_command(text)
                    inv.return_value(None)
                    GLib.idle_add(self.send, (reply + "\n").encode())
                elif method == "StartNotify" and path == TX_PATH:
                    self.notifying = True
                    log("phone subscribed (StartNotify)")
                    inv.return_value(None)
                elif method == "StopNotify" and path == TX_PATH:
                    self.notifying = False
                    log("phone unsubscribed (StopNotify)")
                    inv.return_value(None)
                else:
                    inv.return_dbus_error("org.bluez.Error.NotSupported", method)
            elif iface == "org.bluez.LEAdvertisement1" and method == "Release":
                log("advertisement released by BlueZ")
                inv.return_value(None)
            else:
                inv.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method)
        except Exception as e:  # 任何例外都回 D-Bus 錯誤，不讓 BlueZ 等到逾時
            log("ERR %s %s: %r" % (iface, method, e))
            inv.return_dbus_error("org.bluez.Error.Failed", str(e))

    # ---- notify：改 Value 並發 PropertiesChanged，BlueZ 就會推給手機（每包 ≤20 bytes）
    def send(self, data):
        if not self.notifying:
            return False
        for i in range(0, len(data), 20):
            chunk = data[i:i + 20]
            self.last_tx = chunk
            self.bus.emit_signal(None, TX_PATH, "org.freedesktop.DBus.Properties", "PropertiesChanged",
                                 GLib.Variant("(sa{sv}as)", ("org.bluez.GattCharacteristic1",
                                                             {"Value": GLib.Variant("ay", chunk)}, [])))
        self.n_sent += 1
        return False

    def tick(self):
        line = plot_line()
        if self.notifying:
            self.send((line + "\n").encode())
        if self.n_sent % 10 == 1 or not self.notifying:
            log("TX  -> %s%s" % (line, "" if self.notifying else "  (no subscriber)"))
        return True

    # ---- 註冊
    def export(self):
        for path, ifaces in ((APP_PATH, ["org.freedesktop.DBus.ObjectManager"]),
                             (SVC_PATH, ["org.bluez.GattService1"]),
                             (TX_PATH, ["org.bluez.GattCharacteristic1"]),
                             (RX_PATH, ["org.bluez.GattCharacteristic1"]),
                             (ADV_PATH, ["org.bluez.LEAdvertisement1"])):
            for i in ifaces:
                rid = self.bus.register_object(path, IFACE[i], self.on_method, self.on_get_property, None)
                self.reg_ids.append(rid)

    def register_with_bluez(self, loop):
        """一定要非同步：RegisterApplication 進行中 BlueZ 會回頭呼叫我們的 GetManagedObjects，
        用 call_sync 會把主迴圈擋住 → 兩邊互等 → 10 秒逾時（2026-10-15 實板踩到）。"""
        def on_adv(bus, res):
            try:
                bus.call_finish(res)
                log("advertising as %r" % self.name)
            except Exception as e:
                log("RegisterAdvertisement failed: %s" % e)
                loop.quit()

        def on_app(bus, res):
            try:
                bus.call_finish(res)
                log("GATT application registered (%s)" % NUS_SVC)
            except Exception as e:
                log("RegisterApplication failed: %s" % e)
                loop.quit()
                return
            bus.call(BLUEZ, ADAPTER, "org.bluez.LEAdvertisingManager1", "RegisterAdvertisement",
                     GLib.Variant("(oa{sv})", (ADV_PATH, {})), None,
                     Gio.DBusCallFlags.NONE, 10000, None, on_adv)

        self.bus.call(BLUEZ, ADAPTER, "org.bluez.GattManager1", "RegisterApplication",
                      GLib.Variant("(oa{sv})", (APP_PATH, {})), None,
                      Gio.DBusCallFlags.NONE, 10000, None, on_app)

    def unregister(self):
        for m, i, p in (("UnregisterAdvertisement", "org.bluez.LEAdvertisingManager1", ADV_PATH),
                        ("UnregisterApplication", "org.bluez.GattManager1", APP_PATH)):
            try:
                self.bus.call_sync(BLUEZ, ADAPTER, i, m, GLib.Variant("(o)", (p,)), None,
                                   Gio.DBusCallFlags.NONE, 5000, None)
            except Exception as e:
                log("unregister %s: %s" % (m, e))


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="UNOQ-" + socket.gethostname().upper()[-6:])
    ap.add_argument("--period", type=float, default=1.0)
    ap.add_argument("--no-mfg", action="store_true", help="廣播不帶板況（封包塞不下時用）")
    a = ap.parse_args()

    bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
    srv = HealthServer(bus, a.name, a.period, mfg=not a.no_mfg)
    srv.export()
    loop = GLib.MainLoop()
    srv.register_with_bluez(loop)
    GLib.timeout_add(int(a.period * 1000), srv.tick)
    try:
        log("ready. health now: " + health_line())
        loop.run()
    except KeyboardInterrupt:
        pass
    finally:
        srv.unregister()
        log("bye")


if __name__ == "__main__":
    sys.exit(main())
