#!/usr/bin/env python3
"""W8 語音 AI 小助理：按住說話 → Gemini 即時語音 → 回話從 USB 音效卡播回電腦。

聲音走的路（全部經過 W7 掛好的 USB 音效卡「UNO Q Audio」）：
  電腦麥克風 →（電腦把麥克風「播」到「喇叭 (UNO Q Audio)」）→ 板子 arecord
  → Gemini Live（WebSocket）→ 回話聲音 → 板子 aplay
  →「麥克風 (UNO Q Audio)」→（電腦「聆聽此裝置」）→ 電腦喇叭

它是 agent，不只是聊天：問到板子的事，它會自己呼叫工具去讀板子，不用猜。
  get_board_status  讀溫度、記憶體、負載、開機多久、核心版本
  get_time          台灣現在時間

USB 聲音沒通的時候，網頁上可以把「輸入」「輸出」各自切到「這個網頁」：
  輸入＝瀏覽器麥克風（要在 http://localhost 才開得了，所以先 adb forward）
  輸出＝回答在網頁播一次
兩條路同時存在，才分得出問題在哪一段。

在板子上用 App Lab 的官方容器跑（裡面已有 websockets、fastapi、uvicorn、aplay、arecord）：
  IMG=$(docker images --format '{{.Repository}}:{{.Tag}}' | grep python-apps-base | head -1)
  docker run --rm -it --name voice -u 0 --network host --device /dev/snd \
    -v ~/w08-starter:/w08 -v ~/.gemini_key:/key:ro \
    --entrypoint python3 "$IMG" /w08/voice_agent.py
電腦：adb forward tcp:7790 tcp:7790 → 瀏覽器開 http://localhost:7790 ，按住大按鈕說話、放開等它回答。

環境變數（都可不設）：KEY_FILE=/key  CARD=plughw:UAC2Gadget,0  PORT=7790  VOICE=Kore
  MODEL=gemini-3.8-live,gemini-2.5-flash-native-audio-preview-12-2025（逗號分開＝照順序試，第一個連不上就換下一個）
"""
import asyncio
import base64
import glob
import json
import os
import struct
import time
from contextlib import asynccontextmanager

import uvicorn
import websockets
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, Response

KEY_FILE = os.environ.get("KEY_FILE", "/key")
# 第一個連不上（例如免費層沒開放）就自動換下一個；網頁會顯示現在用的是哪個
MODELS = [m.strip() for m in os.environ.get(
    "MODEL", "gemini-3.8-live,gemini-2.5-flash-native-audio-preview-12-2025").split(",") if m.strip()]
CARD = os.environ.get("CARD", "plughw:UAC2Gadget,0")
PORT = int(os.environ.get("PORT", "7790"))
VOICE = os.environ.get("VOICE", "Kore")
URL = ("wss://generativelanguage.googleapis.com/ws/"
       "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent")
IN_RATE = 16000    # 送給 Gemini：16 kHz、單聲道、16 位元
OUT_RATE = 24000   # Gemini 回來：24 kHz、單聲道、16 位元
PLAY_TIMEOUT = 4   # 秒：aplay 這麼久都塞不出去＝電腦那頭沒有在收 USB 麥克風

try:  # 容器若有 OpenCC，把 Gemini 的簡體逐字稿轉成台灣用字；沒有就原樣
    import opencc
    _CC = opencc.OpenCC("s2twp")

    def tw(s):
        return _CC.convert(s)
except Exception:  # noqa: BLE001
    def tw(s):
        return s

PERSONA = ("你是住在 Arduino UNO Q 板子裡的語音小助理，對象是東華大學上 AIoT 課的同學。"
           "一律用台灣華語回答，口語、親切，每次最多兩句。"
           "同學問到板子的溫度、記憶體、負載、開機多久、核心版本、主機名稱，一定要先呼叫 get_board_status，"
           "照工具回傳的數字回答，不要猜。問到現在幾點、今天幾號、星期幾，呼叫 get_time。不知道就說不知道。")

TOOLS = [{"functionDeclarations": [
    {"name": "get_board_status",
     "description": "讀取這塊 UNO Q 板子現在的狀態：CPU 溫度、可用記憶體、負載、開機多久、核心版本、主機名稱。"},
    {"name": "get_time",
     "description": "取得台灣現在的日期、時間與星期幾。"},
]}]


# ---------------------------------------------------------------- 工具：真的去讀板子
def _read(path, default=""):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def get_board_status():
    temps = []
    for z in sorted(glob.glob("/sys/class/thermal/thermal_zone*/temp")):
        v = _read(z)
        if v.lstrip("-").isdigit():
            temps.append(int(v) / 1000)
    mem = {}
    for line in _read("/proc/meminfo").splitlines():
        k, _, v = line.partition(":")
        mem[k] = int(v.split()[0]) if v.split() else 0
    up = float(_read("/proc/uptime", "0").split()[0])
    return {
        "cpu_temp_c": round(max(temps), 1) if temps else None,
        "mem_total_mb": round(mem.get("MemTotal", 0) / 1024),
        "mem_available_mb": round(mem.get("MemAvailable", 0) / 1024),
        "load_1min": float(_read("/proc/loadavg", "0").split()[0]),
        "uptime_min": round(up / 60, 1),
        "kernel": os.uname().release,
        "hostname": _read("/etc/hostname", os.uname().nodename),
    }


def get_time():
    t = time.gmtime(time.time() + 8 * 3600)
    return {"taiwan_time": time.strftime("%Y-%m-%d %H:%M:%S", t),
            "weekday": "星期" + "一二三四五六日"[t.tm_wday]}


TOOL_FUNCS = {"get_board_status": get_board_status, "get_time": get_time}


# ---------------------------------------------------------------- 狀態（給網頁看）
S = {
    "phase": "idle",        # idle／connecting／listening／thinking／speaking／error
    "msg": "按住按鈕說話",
    "level": 0,             # 這次錄到的最大音量（0–32767）：一直是 0＝聲音沒進板子
    "in_mode": "usb",       # usb＝板子 arecord；web＝瀏覽器麥克風
    "out_mode": "usb",      # usb＝板子 aplay；web＝只在網頁播
    "turns": [],            # 每一輪：聽到什麼、回什麼、叫了哪些工具、等了幾秒
    "model": MODELS[0],     # 連上之後改成真正在用的那個
    "model_note": "",       # 換過模型就寫在這裡（網頁會顯示）
    "card": CARD,
}
ws = None                   # 跟 Gemini 的連線（同一條連線＝它記得前面聊過什麼）
rec_proc = None
rec_task = None
rec_active = False
turn = None
last_wav = b""
play_q = None               # 收到的回話聲音排隊丟給播放工，收訊迴圈永遠不等 aplay
lock = asyncio.Lock()


def wav_bytes(pcm, rate):
    return (b"RIFF" + struct.pack("<I", 36 + len(pcm)) + b"WAVEfmt "
            + struct.pack("<IHHIIHH", 16, 1, 1, rate, rate * 2, 2, 16)
            + b"data" + struct.pack("<I", len(pcm)) + pcm)


def level_of(chunk):
    n = len(chunk) // 2
    if n:
        S["level"] = max(S["level"], max(abs(v) for v in struct.unpack(f"<{n}h", chunk[:n * 2])))


async def send_audio(chunk):
    if ws is not None:
        await ws.send(json.dumps({"realtimeInput": {"audio": {
            "data": base64.b64encode(chunk).decode(), "mimeType": f"audio/pcm;rate={IN_RATE}"}}}))


async def connect():
    """開一條 Gemini Live 連線、送設定、等 setupComplete。"""
    global ws
    key = open(KEY_FILE).read().strip()
    S["phase"], S["msg"] = "connecting", "連線到 Gemini…"
    errors = []
    for model in MODELS:
        conn = await websockets.connect(URL, additional_headers={"x-goog-api-key": key},
                                        max_size=None, ping_interval=20)
        try:
            await conn.send(json.dumps({"setup": {
                "model": f"models/{model}",
                "generationConfig": {"responseModalities": ["AUDIO"],
                                     "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": VOICE}}}},
                "systemInstruction": {"parts": [{"text": PERSONA}]},
                "tools": TOOLS,
                "inputAudioTranscription": {}, "outputAudioTranscription": {},
                # 按住說話：關掉伺服器自己判斷「講完了沒」，改由我們送開始／結束
                "realtimeInputConfig": {"automaticActivityDetection": {"disabled": True}},
            }}))
            first = json.loads(await conn.recv())
        except websockets.ConnectionClosed as e:   # 模型不給用時伺服器直接關連線
            errors.append(f"{model}：{e.code} {str(e.reason)[:160]}")
            continue
        if "setupComplete" not in first:
            await conn.close()
            errors.append(f"{model}：{json.dumps(first, ensure_ascii=False)[:160]}")
            continue
        S["model"] = model
        S["model_note"] = ("" if model == MODELS[0]
                           else f"{MODELS[0]} 連不上（{errors[-1].split('：', 1)[-1][:80]}），改用這個")
        ws = conn
        asyncio.create_task(receiver(conn))
        return
    raise RuntimeError("；".join(errors)[:300])


async def receiver(conn):
    """一直收 Gemini 傳回來的東西：聲音、逐字稿、工具呼叫、這輪結束。"""
    global ws
    audio_since_tool = False   # 工具呼叫之後有沒有收到回話聲音
    tool_turn = False          # 這一輪有沒有叫過工具
    try:
        async for raw in conn:
            msg = json.loads(raw)
            if "toolCall" in msg:
                tool_turn, audio_since_tool = True, False
                replies = []
                for fc in msg["toolCall"].get("functionCalls", []):
                    fn = TOOL_FUNCS.get(fc.get("name"))
                    result = fn() if fn else {"error": "沒有這個工具"}
                    if turn is not None:
                        turn["tools"].append({"name": fc.get("name"), "result": result})
                    replies.append({"id": fc.get("id"), "name": fc.get("name"), "response": result})
                S["phase"] = "thinking"
                S["msg"] = "它在查板子（呼叫工具 " + ", ".join(r["name"] or "" for r in replies) + "）"
                await conn.send(json.dumps({"toolResponse": {"functionResponses": replies}}))
                continue
            sc = msg.get("serverContent", {})
            for p in sc.get("modelTurn", {}).get("parts", []):
                data = p.get("inlineData", {}).get("data")
                if not data:
                    continue
                pcm = base64.b64decode(data)
                if turn is not None and turn.get("wait_s") is None and turn.get("t_end"):
                    turn["wait_s"] = round(time.time() - turn["t_end"], 2)
                audio_since_tool = True
                S["phase"] = "speaking"
                S["msg"] = "它在回答（聲音走 USB 回電腦）" if S["out_mode"] == "usb" else "它在回答（網頁播放）"
                await play_q.put(("pcm", pcm, turn))
            if turn is not None:
                if "inputTranscription" in sc:
                    turn["heard"] += tw(sc["inputTranscription"].get("text", ""))
                if "outputTranscription" in sc:
                    turn["reply"] += sc["outputTranscription"].get("text", "")
            if sc.get("turnComplete"):
                if tool_turn and not audio_since_tool:
                    # 叫工具那一輪到此結束，真正的回答在工具結果送回去之後才來
                    continue
                tool_turn = False
                await play_q.put(("end", None, turn))
    except websockets.ConnectionClosed as e:
        S["phase"], S["msg"] = "error", f"Gemini 連線斷了（{e.code} {str(e.reason)[:120]}），再按一次會重連"
    except Exception as e:  # 收訊迴圈不能悄悄死掉
        S["phase"], S["msg"] = "error", f"{type(e).__name__}: {str(e)[:200]}"
    finally:
        if ws is conn:
            ws = None


async def player_loop():
    """播放工：把回話聲音餵給 aplay；電腦沒在收就放棄這一輪、把原因寫在畫面上。"""
    global last_wav
    player = None
    drop = False
    audio = bytearray()
    while True:
        kind, data, t = await play_q.get()
        if kind == "pcm":
            audio += data
            if drop or S["out_mode"] != "usb":
                continue
            err = ""
            try:
                if player is None:
                    player = await asyncio.create_subprocess_exec(
                        "aplay", "-q", "-D", CARD, "-f", "S16_LE", "-c", "1", "-r", str(OUT_RATE), "-t", "raw",
                        stdin=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                player.stdin.write(data)
                await asyncio.wait_for(player.stdin.drain(), timeout=PLAY_TIMEOUT)
            except asyncio.TimeoutError:
                drop = True
                player.kill()
                await player.wait()
                player = None
                if t is not None:
                    t["play_error"] = ("聲音送不出 USB：電腦沒有在收「麥克風 (UNO Q Audio)」。"
                                       "Windows 開「聆聽此裝置」、Ubuntu 接 loopback，或把輸出切到「這個網頁」")
            except (BrokenPipeError, ConnectionResetError, FileNotFoundError) as e:
                drop = True
                if player is not None:
                    err = (await player.stderr.read()).decode(errors="replace").strip()
                    await player.wait()
                    player = None
                if t is not None:
                    t["play_error"] = "aplay 出錯：" + (err or type(e).__name__)[-200:]
            continue
        # kind == "end"
        if player is not None:
            player.stdin.close()
            try:
                await asyncio.wait_for(player.wait(), timeout=PLAY_TIMEOUT)
                if player.returncode and t is not None and not t.get("play_error"):
                    err = (await player.stderr.read()).decode(errors="replace").strip()
                    t["play_error"] = f"aplay 結束碼 {player.returncode}：{err[-200:]}"
            except asyncio.TimeoutError:
                player.kill()
                await player.wait()
                if t is not None:
                    t["play_error"] = "最後一段送不出 USB：電腦那頭中途停收了"
            player = None
        last_wav = wav_bytes(bytes(audio), OUT_RATE)
        if t is not None:
            t["reply_s"] = round(len(audio) / 2 / OUT_RATE, 2)
            t["done"] = True
            print(json.dumps({k: v for k, v in t.items() if k != "t_end"}, ensure_ascii=False), flush=True)
        audio = bytearray()
        drop = False
        S["phase"], S["msg"] = "idle", "按住按鈕說話"


async def pump_mic(proc):
    """把 arecord 錄到的聲音，每 0.1 秒一段送給 Gemini。"""
    step = IN_RATE * 2 // 10
    while True:
        chunk = await proc.stdout.read(step)
        if not chunk:
            break
        level_of(chunk)
        await send_audio(chunk)


# ---------------------------------------------------------------- 網頁
@asynccontextmanager
async def lifespan(_app):
    """伺服器一起來就把播放工叫起來。"""
    global play_q
    play_q = asyncio.Queue()
    asyncio.create_task(player_loop())
    yield


app = FastAPI(lifespan=lifespan)


@app.post("/start")
async def start():
    global rec_proc, rec_task, rec_active, turn
    async with lock:
        if rec_active:
            return JSONResponse(S)
        try:
            if ws is None:
                await connect()
        except Exception as e:  # noqa: BLE001
            S["phase"], S["msg"] = "error", f"連不上 Gemini：{type(e).__name__}: {str(e)[:200]}"
            return JSONResponse(S)
        turn = {"heard": "", "reply": "", "tools": [], "t_end": None, "wait_s": None,
                "in": S["in_mode"], "out": S["out_mode"]}
        S["turns"] = (S["turns"] + [turn])[-8:]
        S["level"] = 0
        await ws.send(json.dumps({"realtimeInput": {"activityStart": {}}}))
        rec_active = True
        if S["in_mode"] == "usb":
            rec_proc = await asyncio.create_subprocess_exec(
                "arecord", "-q", "-D", CARD, "-f", "S16_LE", "-c", "1", "-r", str(IN_RATE), "-t", "raw",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            rec_task = asyncio.create_task(pump_mic(rec_proc))
            S["phase"], S["msg"] = "listening", "在聽（USB）…說完放開按鈕"
        else:
            S["phase"], S["msg"] = "listening", "在聽（網頁麥克風）…說完放開按鈕"
    return JSONResponse(S)


@app.post("/stop")
async def stop():
    global rec_proc, rec_task, rec_active
    async with lock:
        if not rec_active:
            return JSONResponse(S)
        await asyncio.sleep(0.3)               # 最後半句還在路上，多收 0.3 秒
        rec_active = False
        if rec_proc is not None:
            rec_proc.terminate()
            await rec_proc.wait()
            await rec_task
            rec_proc = rec_task = None
        turn["t_end"] = time.time()
        turn["level"] = S["level"]
        if ws is not None:
            await ws.send(json.dumps({"realtimeInput": {"activityEnd": {}}}))
        S["phase"] = "thinking"
        if S["level"] < 200:
            S["msg"] = ("沒錄到聲音：電腦有把麥克風送到「喇叭 (UNO Q Audio)」嗎？" if S["in_mode"] == "usb"
                        else "沒錄到聲音：瀏覽器有允許用麥克風嗎？")
        else:
            S["msg"] = "它在想…"
    return JSONResponse(S)


@app.post("/mode")
async def mode(body: dict):
    for k in ("in_mode", "out_mode"):
        if body.get(k) in ("usb", "web"):
            S[k] = body[k]
    return JSONResponse(S)


@app.websocket("/mic")
async def mic(sock: WebSocket):
    """瀏覽器麥克風：收 16 kHz、單聲道、16 位元的原始聲音。"""
    await sock.accept()
    try:
        while True:
            chunk = await sock.receive_bytes()
            if rec_active and S["in_mode"] == "web":
                level_of(chunk)
                await send_audio(chunk)
    except WebSocketDisconnect:
        pass


@app.get("/state")
async def state():
    out = dict(S)
    out["turns"] = [{k: v for k, v in t.items() if k != "t_end"} for t in S["turns"]]
    return JSONResponse(out)


@app.get("/reply.wav")
async def reply_wav():
    return Response(last_wav, media_type="audio/wav")


PAGE = """<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>UNO Q 語音小助理</title>
<style>
body{font-family:system-ui,"Noto Sans TC",sans-serif;max-width:720px;margin:24px auto;padding:0 16px;background:#f6f7f9;color:#1d2330}
h1{font-size:22px}#btn{width:100%;padding:34px 0;font-size:24px;border:0;border-radius:18px;background:#1f6feb;color:#fff;touch-action:none;user-select:none;cursor:pointer}
#btn.on{background:#d63a3a}.bar{height:10px;background:#dde3ea;border-radius:5px;margin:10px 0}.bar i{display:block;height:10px;background:#2da44e;border-radius:5px;width:0}
#msg{margin:12px 0;font-size:18px;min-height:1.4em}.t{background:#fff;border-radius:12px;padding:12px 14px;margin:10px 0;box-shadow:0 1px 3px #0001}
.t b{color:#57606a;font-weight:600}.tool{font-family:ui-monospace,monospace;font-size:13px;color:#8250df;white-space:pre-wrap}
.err{color:#d63a3a}small{color:#57606a}.modes{display:flex;gap:18px;flex-wrap:wrap;margin:10px 0;font-size:15px}
.modes fieldset{border:1px solid #dde3ea;border-radius:10px;padding:6px 12px}.modes legend{color:#57606a;font-size:13px}
</style></head><body>
<h1>UNO Q 語音小助理 <small id="model"></small></h1>
<button id="btn">按住說話（或按住空白鍵）</button>
<div class="bar"><i id="lv"></i></div><small>綠條＝板子這次收到的音量；一直沒動＝聲音沒進板子</small>
<div id="msg"></div>
<div class="modes">
<fieldset><legend>聲音進板子（輸入）</legend>
<label><input type="radio" name="in" value="usb" checked> USB 音效卡</label>
<label><input type="radio" name="in" value="web"> 這個網頁的麥克風</label></fieldset>
<fieldset><legend>回答播出來（輸出）</legend>
<label><input type="radio" name="out" value="usb" checked> USB 音效卡</label>
<label><input type="radio" name="out" value="web"> 這個網頁</label></fieldset>
</div>
<small id="webmic"></small>
<div id="turns"></div>
<script>
const $=id=>document.getElementById(id);let down=false,lastDone='',ac=null,micWs=null;
const inMode=()=>document.querySelector('input[name=in]:checked').value,outMode=()=>document.querySelector('input[name=out]:checked').value;
async function post(p,b){try{await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined})}catch(e){}}
document.querySelectorAll('input[type=radio]').forEach(r=>r.addEventListener('change',()=>{post('/mode',{in_mode:inMode(),out_mode:outMode()});if(inMode()==='web')webMic()}));
async function webMic(){
 if(ac)return;
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){$('webmic').textContent='這個網址開不了麥克風：瀏覽器只在 http://localhost 或 https 允許。先 adb forward tcp:7790 tcp:7790，再開 http://localhost:7790';$('webmic').className='err';return}
 try{const st=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}});
  ac=new AudioContext();const src=ac.createMediaStreamSource(st);const proc=ac.createScriptProcessor(4096,1,1);src.connect(proc);proc.connect(ac.destination);
  micWs=new WebSocket((location.protocol==='https:'?'wss':'ws')+'://'+location.host+'/mic');micWs.binaryType='arraybuffer';
  proc.onaudioprocess=e=>{if(!down||!micWs||micWs.readyState!==1)return;const inp=e.inputBuffer.getChannelData(0);const ratio=ac.sampleRate/16000;const n=Math.floor(inp.length/ratio);const out=new Int16Array(n);
   for(let i=0;i<n;i++){const v=Math.max(-1,Math.min(1,inp[Math.floor(i*ratio)]));out[i]=v<0?v*32768:v*32767}micWs.send(out.buffer)};
  $('webmic').textContent='網頁麥克風已開（'+ac.sampleRate+' Hz → 16000 Hz 送板子）';$('webmic').className='';
 }catch(e){$('webmic').textContent='瀏覽器不給麥克風：'+e.name+'（'+e.message+'）';$('webmic').className='err'}
}
async function press(){if(down)return;down=true;$('btn').classList.add('on');if(inMode()==='web'){await webMic();if(ac&&ac.state==='suspended')await ac.resume()}post('/start')}
function release(){if(!down)return;down=false;$('btn').classList.remove('on');post('/stop')}
$('btn').addEventListener('pointerdown',e=>{e.preventDefault();press()});
['pointerup','pointerleave','pointercancel'].forEach(t=>$('btn').addEventListener(t,release));
addEventListener('keydown',e=>{if(e.code==='Space'&&!e.repeat&&e.target.tagName!=='INPUT'){e.preventDefault();press()}});
addEventListener('keyup',e=>{if(e.code==='Space'){e.preventDefault();release()}});
function esc(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
async function tick(){
 try{const s=await (await fetch('/state')).json();$('model').textContent=s.model+(s.model_note?'（'+s.model_note+'）':'');
  $('msg').textContent=s.msg;$('msg').className=s.phase==='error'?'err':'';
  $('lv').style.width=Math.min(100,s.level/120)+'%';
  $('turns').innerHTML=s.turns.slice().reverse().map(t=>'<div class="t"><b>你說：</b>'+esc(t.heard||'（聽不出來）')+
   '<br><b>它說：</b>'+esc(t.reply||'…')+
   t.tools.map(x=>'<div class="tool">🔧 '+esc(x.name)+' → '+esc(JSON.stringify(x.result))+'</div>').join('')+
   (t.wait_s!=null?'<br><small>放開按鈕到它開口：'+t.wait_s+' 秒；回答長 '+(t.reply_s??'…')+' 秒；收到音量 '+(t.level??'…')+'；輸入 '+t.in+'／輸出 '+t.out+'</small>':'')+
   (t.play_error?'<div class="err">'+esc(t.play_error)+'</div>':'')+'</div>').join('');
  const last=s.turns[s.turns.length-1];const done=last&&last.done?String(s.turns.length)+last.reply:'';
  if(done&&done!==lastDone&&(outMode()==='web'||last.play_error)){new Audio('/reply.wav?'+Date.now()).play().catch(()=>{})}
  lastDone=done;
 }catch(e){$('msg').textContent='連不到板子上的程式（它還在跑嗎？）';$('msg').className='err'}
 setTimeout(tick,300)}
tick();
</script></body></html>"""


@app.get("/")
async def index():
    return HTMLResponse(PAGE)


if __name__ == "__main__":
    if os.path.isdir(KEY_FILE):
        raise SystemExit(f"{KEY_FILE} 是資料夾不是檔案：板上還沒建 ~/.gemini_key 就先跑了 docker，"
                         "docker 會自己建一個同名的空資料夾。先 Ctrl-C，板上 rmdir ~/.gemini_key，"
                         "照學生頁第 3 部分建金鑰，再跑一次")
    if not os.path.exists(KEY_FILE):
        raise SystemExit(f"找不到金鑰檔 {KEY_FILE}：先在板子上建 ~/.gemini_key（學生頁第 3 部分）")
    print(f"語音小助理：模型 {' → '.join(MODELS)}、音效卡 {CARD}；電腦先 adb forward tcp:{PORT} tcp:{PORT}，"
          f"再開 http://localhost:{PORT}（USB 網路也可：http://192.168.7.2:{PORT}）", flush=True)
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")
