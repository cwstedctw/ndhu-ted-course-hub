# w08-starter — AIoT W8（2026-10-29）起始檔

三個程式，都在**板子上**跑（先 SSH 或 `adb shell` 進板子）。拿到之後放在 `~/w08-starter/`。

| 檔 | 第幾部分 | 做什麼 | 怎麼跑 |
|---|---|---|---|
| `health_ble.py` | 第一部分 藍牙健康手環 | 板子開一個藍牙服務，每秒把溫度、負載、記憶體送到手機（跟 W7 那份一模一樣） | `python3 ~/w08-starter/health_ble.py --name UNOQ-G03A`（名字換成你的組別＋座位） |
| `build-uac2.sh` | 第二部分 親手編音效卡 | 抓對版的 headers 與原始碼，在 `debian:trixie` 容器裡把 `u_audio.ko`、`usb_f_uac2.ko` 編出來，放 `~/uac2-rebuild/`，最後跟 W7 老師給的 `~/uac2-soundcard/` 比 SHA256 | 先 `bash ~/w08-starter/build-uac2.sh --prefetch`（只抓檔），再 `bash ~/w08-starter/build-uac2.sh`（真的編，約 2 分半） |
| `voice_agent.py` | 第三部分 語音小助理 | 按住網頁按鈕說話 → Gemini 即時語音 → 回話從 USB 音效卡播回電腦；問到板子的事它會自己呼叫工具去讀板子 | 見下面 |

## 語音小助理怎麼跑

1. 金鑰放進板子（只做一次；貼的時候畫面不會顯示、也不會留在指令歷史）：

   ```
   read -s -p "貼上金鑰再按 Enter（畫面不會顯示）: " K; printf %s "$K" > ~/.gemini_key; chmod 600 ~/.gemini_key; echo; wc -c ~/.gemini_key
   ```

2. 用 App Lab 的官方容器跑（裡面已經有 `websockets`、`fastapi`、`uvicorn`、`aplay`、`arecord`）：

   ```
   IMG=$(docker images --format '{{.Repository}}:{{.Tag}}' | grep python-apps-base | head -1); echo $IMG
   docker run --rm -it --name voice -u 0 --network host --device /dev/snd -v ~/w08-starter:/w08 -v ~/.gemini_key:/key:ro --entrypoint python3 "$IMG" /w08/voice_agent.py
   ```

3. 電腦那邊：`"$ADB" forward tcp:7790 tcp:7790`，瀏覽器開 `http://localhost:7790`，按住大按鈕說話、放開等它回答。

停：`Ctrl-C`。卡住：`docker rm -f voice`。每一輪結束它會印一行 JSON（`docker logs voice` 也看得到）。

- 聲音走 USB 音效卡時，電腦要先設好兩個方向的「聆聽此裝置」（學生頁第三部分）；USB 沒通就在網頁上把輸入、輸出切到「這個網頁」先把它跑起來。
- 預設模型 `gemini-3.8-live`，連不上會自動換 `gemini-2.5-flash-native-audio-preview-12-2025`（網頁標題旁會寫）。
- **金鑰是密碼**：不貼進作業、不貼給別人、不放進 git。

## 回家挑戰

替小助理多教一個工具 `get_wifi`（回板子連的 Wi-Fi 名稱與 IP）：在 `voice_agent.py` 裡照 `get_time` 的樣子加一個函式、加進 `TOOLS` 與 `TOOL_FUNCS`，再在 `PERSONA` 告訴它什麼時候該叫。
