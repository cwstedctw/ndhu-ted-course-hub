#!/bin/bash
# W8：在 UNO Q 板子上親手把 USB 音效卡的兩個核心模組編出來（u_audio.ko、usb_f_uac2.ko）。
# 從測試場 arduino-q 的 labs/w15-kernel-module/uac2-usb-soundcard/scripts/build-uac2.sh 改來：
#   產物放 ~/uac2-rebuild/（不碰 W7 老師給你的 ~/uac2-soundcard/），最後把兩邊的 SHA256 放在一起比。
# 需要：板子有網路、有 docker（arduino 在 docker 群組）、核心＝7.0.0-g122c2c22d838。不用 sudo。
# 用法：bash ~/w08-starter/build-uac2.sh --prefetch   # 只先抓：headers、原始碼、debian 映像、編譯器（上課一開始先跑這個，要網路；10/28 實測 2 分 16 秒）
#       bash ~/w08-starter/build-uac2.sh              # 真的編（先 --prefetch 過只要 25 秒、不碰網路；沒先抓過約 2 分 40 秒）
set -e
W=/tmp/uac2-build
OUT=/home/arduino/uac2-rebuild
KVER=$(uname -r)
BRANCH=qcom-v7.0.0-unoq                           # 這個分支的最新 commit＝板子核心的 commit（要對版！）
BASE=https://raw.githubusercontent.com/arduino/linux-qcom/$BRANCH/drivers/usb/gadget/function
IMG=debian:trixie                                 # 裡面的 gcc 14.2.0 跟編這顆核心的那顆同版
IMG_BUILD=uac2-build:trixie                       # 上面那個映像＋裝好 build-essential（--prefetch 時做好，之後編就不用再抓）
# 老師 W7 發的那兩個檔的 SHA256（2026-08-21 編；10/28 在板上重編得到一模一樣的指紋）
EXPECT_U_AUDIO=6c90c70d8cd54db8593ba2d74ce9b0e695a182bd2fca2724c50d390f83dcbdd3
EXPECT_UAC2=5c955ddd1414c1db13acfbf19c26911326683b7a535df4e1e28efc31d6d26f6a

if [ "$KVER" != "7.0.0-g122c2c22d838" ]; then
  echo "你的核心是 $KVER，不是 7.0.0-g122c2c22d838：先照 W7 第一部分升上去（或刷 558）再回來。"
  exit 1
fi

echo "== 0) 這顆核心真的沒有 UAC2 功能嗎（確認再動手）=="
( zcat /proc/config.gz 2>/dev/null || cat /boot/config-$KVER 2>/dev/null ) | grep -E "F_UAC|G_AUDIO" || echo "  → 核心設定裡沒有 UAC，確認要自己補"

echo "== 1) 抓對版 headers（免 sudo；裡面有 Module.symvers 跟 ARM 的 modpost 工具）=="
mkdir -p "$W"; cd "$W"
ls linux-headers-"$KVER"*.deb >/dev/null 2>&1 || apt-get download "linux-headers-$KVER"
rm -rf hdr; dpkg-deb -x linux-headers-*.deb hdr

echo "== 2) 抓對版原始碼（5 個檔），再把它們 #include 的鄰居檔抓齊 =="
mkdir -p src; cd src
for f in f_uac2.c u_audio.c u_audio.h u_uac2.h uac_common.h; do [ -f "$f" ] || curl -fsSL "$BASE/$f" -o "$f"; done
for pass in 1 2 3 4 5; do
  new=0
  for h in $(grep -hoE '#include "[^"]+"' *.c *.h 2>/dev/null | sed -E 's/.*"([^"]+)".*/\1/' | sort -u); do
    [ -f "$h" ] || { curl -fsSL "$BASE/$h" -o "$h" && { echo "  +$h"; new=1; }; }
  done
  [ "$new" = 0 ] && break
done
cat > Makefile <<'MK'
obj-m += u_audio.o
usb_f_uac2-y := f_uac2.o
obj-m += usb_f_uac2.o
MK
ls -la

echo "== 3) 抓 $IMG 映像（第一次才會真的下載）=="
docker pull "$IMG"

echo "== 3b) 在那個映像裡裝好編譯器（build-essential 等，約 75 MB），存成 $IMG_BUILD（有了就不再做）=="
if docker image inspect "$IMG_BUILD" >/dev/null 2>&1; then
  echo "  $IMG_BUILD 已經有了"
else
  printf 'FROM %s\nRUN apt-get update -qq && apt-get install -y -qq build-essential bc kmod && rm -rf /var/lib/apt/lists/*\n' "$IMG" \
    | docker build -q -t "$IMG_BUILD" -
fi
if [ "$1" = "--prefetch" ]; then
  echo "先抓好了。等一下再跑一次（不加 --prefetch）就會真的編。"
  exit 0
fi

echo "== 4) 在容器裡編 =="
docker run --rm -v "$W":/work "$IMG_BUILD" bash -c "
  make -C /work/hdr/usr/src/linux-headers-$KVER M=/work/src modules
  echo '-- vermagic（要對上 $KVER 才載得進去）--'
  modinfo /work/src/usb_f_uac2.ko | grep vermagic"

echo "== 5) 存到 $OUT（/tmp 重開機會清掉）=="
mkdir -p "$OUT"
cp "$W/src"/u_audio.ko "$W/src"/usb_f_uac2.ko "$W/src"/Makefile "$OUT"/
ls -la "$OUT"

echo "== 6) 跟老師 W7 發的那兩個檔比指紋（SHA256；老師的指紋寫在這支腳本開頭）=="
for f in u_audio.ko usb_f_uac2.ko; do
  mine=$(sha256sum "$OUT/$f" | cut -c1-64)
  if [ "$f" = u_audio.ko ]; then ref=$EXPECT_U_AUDIO; else ref=$EXPECT_UAC2; fi
  if [ "$mine" = "$ref" ]; then echo "$f  一模一樣  $mine"; else echo "$f  不一樣！  你的 $mine  老師的 $ref"; fi
  if [ -f "$HOME/uac2-soundcard/$f" ] && [ "$(sha256sum "$HOME/uac2-soundcard/$f" | cut -c1-64)" != "$ref" ]; then
    echo "  （注意：你板上 ~/uac2-soundcard/$f 的指紋跟老師 W7 發的不同，先問老師）"
  fi
done
echo "OK → 回學生頁 2-3：把兩個檔複製進 ~/uac2-soundcard/ 再重開機，讓 hook 載你自己編的（模組正在被音效卡用著，rmmod 會被拒）"
