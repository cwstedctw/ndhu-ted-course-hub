# SPDX-FileCopyrightText: 2026
# SPDX-License-Identifier: MPL-2.0

import threading
import time
from datetime import UTC, datetime

from arduino.app_bricks.video_objectdetection import VideoObjectDetection
from arduino.app_bricks.web_ui import WebUI
from arduino.app_peripherals.camera import WebSocketCamera
from arduino.app_utils import App


ui = WebUI()

# The browser sends JPEG frames through ADB USB forwarding to this camera.
# No Wi-Fi connection and no USB hub are needed.
camera = WebSocketCamera(
    port=8080,
    resolution=(320, 240),
    fps=8,
    secret=None,
    encrypt=False,
)

detection = VideoObjectDetection(
    camera,
    confidence=0.5,
    debounce_sec=0.25,
)


def report_camera_status(event_type: str, data: dict) -> None:
    """Write simple camera connection messages to the App log."""
    print(f"camera:{event_type} {data}", flush=True)


def report_detections(detections: dict) -> None:
    """Send reliable AI statistics to the page and keep a lightweight log."""
    faces = detections.get("face", [])
    face_count = len(faces)
    confidences = [float(face.get("confidence", 0.0)) for face in faces]
    timestamp = datetime.now(UTC).isoformat(timespec="milliseconds")

    ui.send_message(
        "ai_stats",
        {
            "face_count": face_count,
            "max_confidence": max(confidences, default=None),
            "timestamp": timestamp,
        },
    )

    if face_count:
        print(f"{timestamp} faces={face_count}", flush=True)


# ── 板子實際收到幾張畫面（不管是瀏覽器還是 Python 送的）────────────────────
#
# 為什麼要在板子這層數：頁面只量得到「自己送了幾張」，
# 用 mac-sender 的 Python 送畫面時，頁面根本不知道送了多少（只能顯示「—」）。
# 板子是唯一看得到所有來源的地方。
#
# 做法＝包一層 `camera.capture()`。VideoObjectDetection 的 camera_loop 每幀都呼叫它，
# 回傳 None 表示這輪沒有新畫面，所以只數非 None 的。
# 這是包在我們自己的 App 裡，沒有改到 arduino 的函式庫。
#
# ⚠️ 注意 `capture()` 內建 FPS 節流（`1/fps`，見 base_camera.py）：
# 上面 WebSocketCamera 設 fps=8，所以這個數字**最高就是 8**，
# 送再快也一樣。要更快就把上面的 fps 調大。

received_frames = 0
_frame_lock = threading.Lock()
_original_capture = camera.capture


def _counting_capture():
    global received_frames
    frame = _original_capture()
    if frame is not None:
        with _frame_lock:
            received_frames += 1
    return frame


camera.capture = _counting_capture


def _report_throughput() -> None:
    """每秒把板子實際收到的張數推給頁面。"""
    global received_frames
    last_at = time.monotonic()

    while True:
        time.sleep(1.0)
        now = time.monotonic()
        elapsed = max(now - last_at, 0.001)
        last_at = now

        with _frame_lock:
            count = received_frames
            received_frames = 0

        ui.send_message("board_throughput", {"fps": count / elapsed})


threading.Thread(target=_report_throughput, daemon=True).start()

camera.on_status_changed(report_camera_status)
detection.on_detect_all(report_detections)

App.run()
