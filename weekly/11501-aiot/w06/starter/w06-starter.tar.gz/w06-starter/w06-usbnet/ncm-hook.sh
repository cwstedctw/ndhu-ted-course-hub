#!/bin/sh
# usbnet v2：繫進 adbd.service 生命週期的 gadget 擴充 hook（NCM 網卡＋UAC2 音效卡）。
#
# 為什麼這樣設計（2026-07-28 事故的教訓）：
# - adbd.service 自己就是 base gadget 的主人：ExecStartPre=setup（建 g1+ffs+acm）、
#   ExecStartPost=activate（綁 UDC）、ExecStopPost=reset（拆光）。
# - setup 的 ln -s 不容忍殘留、reset 遇到「它不認識的 link」會炸——所以任何
#   「第二個服務去搶 gadget」的做法都跟 adbd 的重啟生命週期相剋（事故根因）。
# - 正解＝把我們的 function 用 drop-in 繫進同一個生命週期：
#     add   （drop-in ExecStartPre，排在 setup 之後）：加 function+link，「不碰 UDC」——
#            之後 activate 第一次綁 UDC 時我們已在場 → 零 unbind、零 rebind、零斷線
#     remove（drop-in ExecStop）：正常停止時先拆我們的 link → 原 reset 才拆得動它的
#     sweep （drop-in ExecStopPost，排在原 reset 之後）：不論 reset 成敗，把殘骸清到
#            「g1 不存在」→ 下一輪 setup 永遠從零開始、永遠成功（自癒閉環）
# - 全程容忍失敗（exit 0）：最壞情況＝功能沒掛，adbd 照常活著。絕不擋 adb。
G=/sys/kernel/config/usb_gadget/g1
C=$G/configs/c.1
UAC2_DIR=/home/arduino/uac2-soundcard
LOG=/tmp/ncm-hook.log

log() {
  # 固定回傳成功：log 自己的失敗絕不能污染呼叫端的 &&/|| 控制流程（立霧終審）
  echo "$(date '+%m-%d %H:%M:%S') [$1] $2" >>"$LOG" 2>/dev/null || :
  logger -t ncm-hook "[$1] $2" 2>/dev/null || :
  return 0
}

add() {
  [ -d "$C" ] || { log add "c.1 不存在（setup 沒跑？）放棄"; exit 0; }

  # --- NCM（in-tree，modprobe 即有）---
  if modprobe usb_f_ncm 2>/dev/null; then
    NCM_READY=1
    if [ ! -d "$G/functions/ncm.usb0" ]; then
      # 屬性寫入用 && 串成同一個成功條件：任一失敗＝function 不完整，不建 link（立霧終審）
      if mkdir "$G/functions/ncm.usb0" 2>/dev/null \
         && echo 02:AA:1A:22:21:93 > "$G/functions/ncm.usb0/host_addr" 2>/dev/null \
         && echo 02:AA:1A:22:21:94 > "$G/functions/ncm.usb0/dev_addr" 2>/dev/null; then
        :
      else
        rmdir "$G/functions/ncm.usb0" 2>/dev/null
        log add "ncm function 初始化失敗（已清目錄）"
        NCM_READY=0
      fi
    fi
    if [ "$NCM_READY" = 1 ]; then
      # 既有 link 不重建（ln -sf 無 -n 會跟隨 symlink 誤入目錄）；不存在才 ln -s
      if [ -L "$C/ncm.usb0" ]; then
        log add "ncm 已掛（既有 link）"
      elif ln -s "$G/functions/ncm.usb0" "$C/ncm.usb0" 2>/dev/null; then
        log add "ncm 已掛"
      else
        log add "ncm link 失敗"
      fi
    fi
  else
    log add "modprobe usb_f_ncm 失敗，跳過 ncm"
  fi

  # --- UAC2（out-of-tree，側載 .ko；vermagic 不合就靜默跳過）---
  if [ -f "$UAC2_DIR/u_audio.ko" ]; then
    grep -q '^u_audio ' /proc/modules || insmod "$UAC2_DIR/u_audio.ko" 2>/dev/null
    grep -q '^usb_f_uac2 ' /proc/modules || insmod "$UAC2_DIR/usb_f_uac2.ko" 2>/dev/null
    if grep -q '^usb_f_uac2 ' /proc/modules; then
      UAC2_READY=1
      if [ ! -d "$G/functions/uac2.usb0" ]; then
        if mkdir "$G/functions/uac2.usb0" 2>/dev/null \
           && echo 3 > "$G/functions/uac2.usb0/c_chmask" 2>/dev/null \
           && echo 3 > "$G/functions/uac2.usb0/p_chmask" 2>/dev/null \
           && echo "UNO Q Audio" > "$G/functions/uac2.usb0/function_name" 2>/dev/null; then
          :
        else
          rmdir "$G/functions/uac2.usb0" 2>/dev/null
          log add "uac2 function 初始化失敗（已清目錄）"
          UAC2_READY=0
        fi
      fi
      if [ "$UAC2_READY" = 1 ]; then
        if [ -L "$C/uac2.usb0" ]; then
          log add "uac2 已掛（既有 link）"
        elif ln -s "$G/functions/uac2.usb0" "$C/uac2.usb0" 2>/dev/null; then
          log add "uac2 已掛"
        else
          log add "uac2 link 失敗"
        fi
      fi
    else
      log add "uac2 模組載不進（vermagic？）跳過"
    fi
  fi
  exit 0
}

remove() {
  if rm -f "$C/ncm.usb0" "$C/uac2.usb0" 2>/dev/null; then
    log remove "已拆我們的 link"
  else
    log remove "拆 link 失敗，交由 sweep 收尾"
  fi
  exit 0
}

sweep() {
  # 原 reset 之後跑：reset 成功＝g1 已不在、這裡無事；reset 炸＝把殘骸清到底
  [ -d "$G" ] || { log sweep "g1 已不在（reset 成功）"; exit 0; }
  echo "" > "$G/UDC" 2>/dev/null
  umount /dev/usb-ffs/adb 2>/dev/null
  # 不 rmdir /dev/usb-ffs/adb：原廠 setup 有 mkdir -p 所以本來安全，但留著目錄零風險（兩員審查同建議）
  for l in "$C"/*; do
    [ -L "$l" ] && rm -f "$l" 2>/dev/null
  done
  rmdir "$C/strings/0x409" 2>/dev/null
  rmdir "$C" 2>/dev/null
  for f in "$G"/functions/*; do
    [ -d "$f" ] && rmdir "$f" 2>/dev/null
  done
  rmdir "$G/strings/0x409" 2>/dev/null
  rmdir "$G" 2>/dev/null
  [ -d "$G" ] && log sweep "清不乾淨（殘：$(ls "$G" 2>/dev/null | tr '\n' ' ')）" || log sweep "g1 已清空"
  exit 0
}

case "$1" in
  add) add ;;
  remove) remove ;;
  sweep) sweep ;;
  *) echo "用法: $0 [add|remove|sweep]"; exit 1 ;;
esac
