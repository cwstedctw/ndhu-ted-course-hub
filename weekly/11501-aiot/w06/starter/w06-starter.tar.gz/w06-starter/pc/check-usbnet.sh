#!/bin/sh
# W6：在電腦（Ubuntu／macOS）上檢查「板子變成的 USB 網卡」通不通。唯讀，一行都不改系統。
# 用法：sh check-usbnet.sh
BOARD=192.168.7.2
echo "== 1 這台電腦的網卡（找 192.168.7.x 那一張）"
if command -v ip >/dev/null 2>&1; then
  ip -4 -br addr
else
  ifconfig 2>/dev/null | grep -E "^[a-z]|inet "
fi
echo
echo "== 2 USB 網卡上的 IP"
if command -v ip >/dev/null 2>&1; then
  ip -4 -br addr | grep -E "192\.168\.7\." || echo "沒有任何網卡拿到 192.168.7.x（板子還沒變網卡，或電腦還沒拿到 IP）"
else
  ifconfig 2>/dev/null | grep -E "192\.168\.7\." || echo "沒有任何網卡拿到 192.168.7.x"
fi
echo
echo "== 3 預設路由（上網那條）還在不在——應該不是走 USB 網卡"
if command -v ip >/dev/null 2>&1; then ip route show default; else netstat -rn 2>/dev/null | grep -E "^default|^0\.0\.0\.0" | head -2; fi
echo
echo "== 4 ping 板子（USB 網路）"
ping -c 5 $BOARD 2>&1 | tail -3
echo
echo "== 5 板子上的網頁（App 要先 start）"
curl -s -o /dev/null -m 3 -w "http://$BOARD:7000 → HTTP %{http_code}（%{time_total}s）\n" http://$BOARD:7000/ || echo "連不到 $BOARD:7000"
