#!/usr/bin/env python3
"""localhost → UNO Q USB 網卡 的 TCP 轉接。

為什麼要這支：瀏覽器的攝影機 API（getUserMedia）只在「安全內容」下存在＝
HTTPS 或 localhost。板子直連網址 http://192.168.7.2:7000 兩者都不是，
相機 API 會整個消失（App 會印「這個瀏覽器不支援攝影機功能」）。

所以：讓瀏覽器連 127.0.0.1（滿足 localhost 例外），底下走 USB 網卡到板子。
效果＝跟 adb forward 一樣的網址，但傳輸層是 USB 網路，**完全不經 adb**，
不會有 adb forward 那個「自己掉線」的老問題。

用法： python3 usbnet-bridge.py [板子IP]
停止： Ctrl-C
"""
import os
import socket
import sys
import threading
import time

if len(sys.argv) > 1 and sys.argv[1] in ("-h", "--help"):
    print(__doc__.strip())
    raise SystemExit(0)

BOARD = sys.argv[1] if len(sys.argv) > 1 else "192.168.7.2"

# (本機埠, 板子埠, 用途) —— 沿用原本 adb forward 的埠號，網頁不用改
PORTS = [
    (17000, 7000, "操作頁面"),
    (18080, 8080, "影像上傳"),
    (14912, 4912, "AI 框選"),
]


def pump(src, dst):
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
    except OSError:
        pass
    finally:
        for s in (src, dst):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            s.close()


def handle(client, board_port):
    try:
        upstream = socket.create_connection((BOARD, board_port), timeout=5)
    except OSError as exc:
        print(f"  ✗ 連不到 {BOARD}:{board_port}（{exc}）", flush=True)
        client.close()
        return
    upstream.settimeout(None)
    threading.Thread(target=pump, args=(client, upstream), daemon=True).start()
    threading.Thread(target=pump, args=(upstream, client), daemon=True).start()


def listen(local_port, board_port, label):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Windows 的 SO_REUSEADDR 語義不同：會允許兩個行程「同時」綁同一埠，
    # 舊 bridge 沒死流量就分裂難查——Windows 用預設（本就排他），其他平台照設。
    if os.name != "nt":
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", local_port))
    srv.listen(64)
    print(f"  127.0.0.1:{local_port} → {BOARD}:{board_port}  ({label})", flush=True)
    while True:
        client, _ = srv.accept()
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        handle(client, board_port)


print(f"USB 網路轉接啟動（板子 {BOARD}，零 adb）：", flush=True)
for local_port, board_port, label in PORTS:
    threading.Thread(target=listen, args=(local_port, board_port, label), daemon=True).start()
print("  → 瀏覽器開 http://127.0.0.1:17000", flush=True)
# 不用 Event().wait()：Windows 主執行緒在無 timeout 的 wait 裡吃不到 Ctrl-C
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("bridge 結束", flush=True)
