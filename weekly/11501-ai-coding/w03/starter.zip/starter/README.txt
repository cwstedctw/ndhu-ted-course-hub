W3 起步包──和AI一起寫程式（115-1）

這包裡有什麼
  v0-sample.html   沒有上週單檔的人用這份，改名成 index.html，同分。
  v1-sample.html   照工單 v1 做出來的對照版。先自己試，卡住了再看。
  工單-v1.md       卡 6 貼給 AI 的那張工單，整份就是提示詞本體。
  提示詞.md        八張卡的提示詞，照順序，純文字好複製。
  AGENTS.md        規則檔，Codex 動工前會讀。
  .agents/rules/課堂規則.md   同一份規則，Antigravity 讀這個位置。

用這包──路線 A（Antigravity／Codex）
  1. 先在下載夾按右鍵「全部解壓縮」，再把整個 starter 資料夾改名 my-panel。
  2. 用 agent 的「開啟資料夾」打開 my-panel；沒有上週單檔的人，把 v0-sample.html 改名 index.html。
  3. 打開 提示詞.md，從卡 1 開始一段一段貼。每條指令看過再按同意。

用這包──路線 B（全程瀏覽器）
  1. 解壓縮，把 v0-sample.html（或你上週那個單檔）改名 index.html。
  2. 到 github.com 建一個 Public 的 my-panel，把 index.html 上傳進去。
  3. 把 工單-v1.md 整份貼給 ChatGPT 或 Gemini 的網頁版，要它回一整份 index.html，再貼回 GitHub 的編輯器。

提醒
  這個 repo 是公開的：不放真名、學號、電話，任何地方都不放密碼。
  壓縮檔裡直接雙擊改檔會存到暫存資料夾，關掉就不見──一定先解壓縮。
