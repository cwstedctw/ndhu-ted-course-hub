# Trailer script format / 預告片腳本格式

The headings and the `key: value` lines are fixed; `make_trailer.py` parses them. Keep the order. / 標題與 `key: value` 的寫法固定，程式靠它們解析；順序照抄。

```markdown
# Trailer script
title: <one line>
music: assets/music.mp3
disclosure: Research and script by my AI team (OpenCode); facts checked by me, the captain, on the card handed in with this video; images: my own screenshots (or text cards drawn by the script); voice edge-tts; video assembled with ffmpeg.

## Shot 1
image: assets/shot1.png
caption: <15 words or fewer; burned in as the subtitle>
voice: <one or two sentences; edge-tts reads them aloud>
source: <a file in workspace/shared/ plus the line number>

## Shot 2
(same four lines)

## Shot 3
(same four lines)
```

Rules / 規則

- `music:` is optional. Leave the line out if there is no music; if `assets/music.mp3` exists it is used anyway. / `music:` 可省略；沒音樂就不寫這行；`assets/music.mp3` 存在就會自動用。
- `image:` is optional. Use `clip: assets/shot2.mp4` instead for a short video (the first seconds are used, scaled to 720p, its own sound is dropped). Leave it out: if `assets/shotN.png` (or `shotN.mp4`) exists it is used, otherwise the shot becomes a dark text card with the title and the caption. / `image:` 可省略；短片用 `clip:`（取前幾秒、縮到 720p、不用它的聲音）；不寫時，`assets/shotN.png`（或 `shotN.mp4`）有就用、沒有就變成文字卡。
- `caption:` 15 words or fewer (the script counts English words; a Chinese caption of about 20 characters is fine). It becomes the subtitle of that shot. / 字幕英文 15 個字以內（程式數的是英文單字；中文約 20 字），會燒進那一鏡。
- `voice:` one or two sentences. Mostly Chinese text gets the Chinese voice, otherwise the English voice. A shot lasts as long as the narration plus a little, at least 6 and at most 10 seconds, so keep it short. / 旁白一兩句；中文多就用中文語音。一鏡＝旁白長度再多一點，最短 6 秒、最長 10 秒，所以別寫長。
- `source:` where the fact in this shot comes from: a file in `workspace/shared/` with the line number (for example `workspace/shared/campus-picker.html line 183`). Only files in `workspace/shared/` count; no URLs. The leader checks it; the script only requires that it is there. / 這一鏡的事實從哪來：`workspace/shared/` 的檔名＋行號；只准 shared 裡的檔案，不准網址。領隊會查；程式只要求有寫。
- `disclosure:` one line, shown on the closing card for 4 seconds. Name who researched, who checked the facts and when (always the captain, never the AI), where the images came from, and which tools made the voice and the video. / 揭露一行，片尾卡顯示 4 秒：誰研究、誰查核、何時、圖從哪來、聲音與影片用什麼做的。

Handoff line (the team charter asks for one in every outbox file): put it at the very end, after Shot 3, starting with `HANDOFF:`. The script ignores it. / 交接行（公約要求 outbox 每個檔都有一行）：寫在檔案最後、Shot 3 之後，以 `HANDOFF:` 開頭；程式會略過它。

Example of one shot, with a real fact from the W6 picker page (replace it with your own project): / 一鏡的範例，事實取自 W6 挑選器（換成你自己的作品）：

```markdown
## Shot 1
caption: One click picks something to do between classes.
voice: Choose a place, your free time and your energy, then press "Pick for me".
source: workspace/shared/campus-picker.html line 6 and line 183
```
