r"""make_trailer.py - build a 30-second trailer (mp4) from a script markdown.

Run from the project folder (the one that holds AGENTS.md):

  python .agents/skills/make-trailer/scripts/make_trailer.py --script workspace/outbox/<date>-trailer-script-v2.md --assets assets --out out

What it needs: ffmpeg (on PATH, under tools/ffmpeg/**/bin, or given with --ffmpeg), Python 3.10+,
Pillow, edge-tts (and network access for the narration). Nothing else is downloaded.

What it writes into --out: trailer.mp4, trailer.srt, check.txt (plus a work/ folder with the pieces).
Exit code 0 = all six check lines (duration/shots/captions/disclosure/audio/file) are OK, or the only FAIL is audio because the voice service is offline; 2 = any other FAIL (read check.txt and tell the captain). Lines starting with note:/voice: are hints, not checks.

Standard library + Pillow + edge-tts; every subprocess is a list of arguments (no shell).
"""
from __future__ import annotations

import argparse
import asyncio
import glob
import os
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------- constants
W, H = 1280, 720
FPS = 30
SHOT_MIN, SHOT_MAX = 6.0, 10.0      # seconds per shot
VOICE_PAD = 0.8                     # seconds added after the narration
OFFLINE_SHOT = 8.0                  # seconds per shot when there is no narration
DISCLOSURE_SEC = 4.0
TARGET_LO, TARGET_HI = 28.0, 32.0   # what we aim for
TOL_LO, TOL_HI = 25.0, 35.0         # what still passes
MUSIC_DB = "-18dB"
FONT_CANDIDATES = ["C:/Windows/Fonts/msjh.ttc", "C:/Windows/Fonts/arial.ttf"]
SUB_STYLE = "FontName=Microsoft JhengHei,FontSize=28,Alignment=2,MarginV=28,Outline=1,Shadow=0,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000"
TTS_TIMEOUT = 60

try:  # Windows consoles are often not UTF-8; never crash on a dash or a Chinese character
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def say(msg: str) -> None:
    print(msg, flush=True)


# ---------------------------------------------------------------- tools
class ToolError(Exception):
    pass


def find_ffmpeg(explicit: str | None, project: Path) -> tuple[Path, Path]:
    """Return (ffmpeg, ffprobe). Order: --ffmpeg, PATH, tools/ffmpeg/**/bin, then WinGet's own install folders."""
    candidates: list[Path] = []
    if explicit:
        p = Path(explicit)
        if p.is_dir():
            p = p / "ffmpeg.exe"
        if not p.exists():
            raise ToolError(
                f"ffmpeg was not found at the path you gave: {p}\n"
                "Stop and tell the captain. Then either run Step 0 of SKILL.md (winget install Gyan.FFmpeg, or unzip the\n"
                "official zip into tools/ffmpeg/), or pass the real path of ffmpeg.exe with --ffmpeg."
            )
        candidates.append(p)
    else:
        on_path = shutil.which("ffmpeg")
        if on_path:
            candidates.append(Path(on_path))
        for pat in ("tools/ffmpeg/**/bin/ffmpeg.exe", "tools/ffmpeg/**/bin/ffmpeg"):
            candidates += [Path(x) for x in glob.glob(str(project / pat), recursive=True)]
        # winget installs ffmpeg under %LOCALAPPDATA%\Microsoft\WinGet, and a window opened before the install does not see the new PATH
        local = os.environ.get("LOCALAPPDATA")
        if local:
            for pat in (r"Microsoft\WinGet\Links\ffmpeg.exe", r"Microsoft\WinGet\Packages\Gyan.FFmpeg*\**\bin\ffmpeg.exe"):
                candidates += [Path(x) for x in glob.glob(str(Path(local) / pat), recursive=True)]
    for ff in candidates:
        probe = ff.with_name("ffprobe" + ff.suffix)
        if probe.exists():
            return ff, probe
        if ff.exists():
            raise ToolError(f"found {ff} but not ffprobe next to it; a normal ffmpeg install has both. Tell the captain.")
    raise ToolError(
        "ffmpeg is not installed, or this shell cannot see it yet.\n"
        "Stop and tell the captain, then do Step 0 of SKILL.md: winget install --id Gyan.FFmpeg -e ... , or unzip\n"
        "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip into tools/ffmpeg/ inside this project.\n"
        "A fresh install is only on PATH in a new window; until then pass --ffmpeg <full path to ffmpeg.exe>."
    )


def run(cmd: list, cwd: Path | None = None) -> subprocess.CompletedProcess:
    cmd = [str(c) for c in cmd]
    cp = subprocess.run(cmd, cwd=str(cwd) if cwd else None, capture_output=True, text=True,
                        encoding="utf-8", errors="replace")
    if cp.returncode != 0:
        tail = "\n".join(cp.stderr.strip().splitlines()[-12:])
        raise ToolError(f"command failed (exit {cp.returncode}): {' '.join(cmd[:3])} ...\n{tail}")
    return cp


def probe_duration(ffprobe: Path, media: Path) -> float:
    cp = run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "json", media])
    return float(json.loads(cp.stdout)["format"]["duration"])


# ---------------------------------------------------------------- script
class ScriptError(Exception):
    pass


KEY_RE = re.compile(r"^\s*(?:[-*]\s*)?([A-Za-z_]+)\s*:\s*(.*?)\s*$")
SHOT_RE = re.compile(r"^\s*#{2,}\s*Shot\s*(\d+)\b", re.IGNORECASE)


def parse_script(path: Path) -> dict:
    if not path.exists():
        raise ScriptError(f"script file not found: {path}. Ask the captain which file to use.")
    text = path.read_text(encoding="utf-8-sig")
    head: dict[str, str] = {}
    shots: list[dict] = []
    cur: dict | None = None
    for raw in text.splitlines():
        line = raw.split(" ←")[0].rstrip()          # drop the explanatory arrows from the template
        if not line.strip() or line.strip().startswith("```"):
            continue
        m = SHOT_RE.match(line)
        if m:
            cur = {"n": int(m.group(1))}
            shots.append(cur)
            continue
        if line.lstrip().startswith("#"):
            continue
        m = KEY_RE.match(line)
        if not m:
            continue
        key, val = m.group(1).lower(), m.group(2).strip()
        if val.startswith("<") and val.endswith(">"):   # the whole value is still a template placeholder like <one line>
            val = ""
        if cur is None:
            head[key] = val
        else:
            cur[key] = val

    missing = [k for k in ("title", "disclosure") if not head.get(k)]
    for s in shots:
        for k in ("caption", "voice", "source"):
            if not s.get(k):
                missing.append(f"Shot {s['n']} {k}")
    if missing:
        raise ScriptError("the script is missing: " + ", ".join(missing) +
                          ". Stop and ask the captain; do not invent facts, captions or sources.")
    return {"title": head["title"], "disclosure": head["disclosure"], "music": head.get("music", ""), "shots": shots}


def resolve_asset(ref: str, project: Path, assets: Path) -> Path | None:
    if not ref:
        return None
    p = Path(ref)
    for cand in ([p] if p.is_absolute() else [project / p, assets / p.name]):
        if cand.exists():
            return cand
    return None


# ---------------------------------------------------------------- pictures (Pillow)
def load_font(size: int):
    from PIL import ImageFont
    for f in FONT_CANDIDATES:
        if Path(f).exists():
            try:
                return ImageFont.truetype(f, size)
            except Exception:
                continue
    return ImageFont.load_default()


def is_cjk(ch: str) -> bool:
    o = ord(ch)
    return (0x3000 <= o <= 0x303F or 0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or
            0xF900 <= o <= 0xFAFF or 0xFF00 <= o <= 0xFFEF)


def cjk_ratio(text: str) -> float:
    chars = [c for c in text if not c.isspace()]
    return (sum(is_cjk(c) for c in chars) / len(chars)) if chars else 0.0


def wrap(draw, text: str, font, max_w: int) -> list[str]:
    """Greedy wrap that breaks Latin text on spaces and CJK text per character."""
    tokens: list[str] = []
    buf = ""
    for ch in text:
        if is_cjk(ch):
            if buf:
                tokens.append(buf); buf = ""
            tokens.append(ch)
        elif ch == " ":
            if buf:
                tokens.append(buf); buf = ""
            tokens.append(" ")
        else:
            buf += ch
    if buf:
        tokens.append(buf)
    lines, cur = [], ""
    for t in tokens:
        trial = cur + t
        if draw.textlength(trial, font=font) <= max_w or not cur.strip():
            cur = trial
        else:
            lines.append(cur.rstrip()); cur = t.lstrip()
    if cur.strip():
        lines.append(cur.rstrip())
    return lines


def draw_block(draw, text: str, font, top: int, max_w: int, fill, line_gap: int = 10, align_center=True) -> int:
    y = top
    for ln in wrap(draw, text, font, max_w):
        w = draw.textlength(ln, font=font)
        x = (W - w) / 2 if align_center else (W - max_w) / 2
        draw.text((x, y), ln, font=font, fill=fill)
        y += font.size + line_gap
    return y


def frame_from_image(src: Path, out_png: Path) -> None:
    from PIL import Image
    img = Image.open(src).convert("RGB")
    img.thumbnail((W, H))
    canvas = Image.new("RGB", (W, H), (0, 0, 0))
    canvas.paste(img, ((W - img.width) // 2, (H - img.height) // 2))
    canvas.save(out_png)


def frame_text_card(title: str, caption: str, shot_no: int, out_png: Path) -> None:
    from PIL import Image, ImageDraw
    canvas = Image.new("RGB", (W, H), (22, 52, 59))
    d = ImageDraw.Draw(canvas)
    d.text((60, 48), f"{title}", font=load_font(34), fill=(205, 225, 220))
    d.text((60, 96), f"Shot {shot_no}", font=load_font(26), fill=(140, 180, 175))
    d.rectangle([60, 140, 200, 143], fill=(8, 126, 139))
    draw_block(d, caption, load_font(60), 250, W - 160, (255, 253, 248), line_gap=16)
    canvas.save(out_png)


def frame_disclosure(disclosure: str, out_png: Path) -> None:
    from PIL import Image, ImageDraw
    canvas = Image.new("RGB", (W, H), (12, 20, 24))
    d = ImageDraw.Draw(canvas)
    d.text((60, 70), "AI disclosure / AI 揭露", font=load_font(34), fill=(205, 225, 220))
    d.rectangle([60, 120, 200, 123], fill=(231, 111, 81))
    draw_block(d, disclosure, load_font(36), 190, W - 160, (240, 240, 235), line_gap=14, align_center=False)
    canvas.save(out_png)


# ---------------------------------------------------------------- narration (edge-tts)
def tts(text: str, voice: str, out_mp3: Path) -> tuple[bool, str]:
    try:
        import edge_tts  # noqa
    except Exception as e:  # not installed
        return False, f"edge-tts is not installed ({e}); Step 0: python -m pip install --user edge-tts"

    async def _go():
        comm = edge_tts.Communicate(text, voice)
        await comm.save(str(out_mp3))

    try:
        asyncio.run(asyncio.wait_for(_go(), timeout=TTS_TIMEOUT))
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"
    if not out_mp3.exists() or out_mp3.stat().st_size < 1000:
        return False, "edge-tts returned an empty file"
    return True, ""


# ---------------------------------------------------------------- ffmpeg pieces
VIDEO_ENC = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", "-r", str(FPS)]
AUDIO_ENC = ["-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2"]
SCALE = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:color=black,fps={FPS},format=yuv420p,setsar=1"


def segment(ffmpeg: Path, visual: Path, is_clip: bool, voice: Path | None, dur: float, out_mp4: Path) -> None:
    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error"]
    if is_clip:
        cmd += ["-stream_loop", "-1", "-i", visual]
    else:
        cmd += ["-loop", "1", "-framerate", str(FPS), "-i", visual]
    if voice:
        cmd += ["-i", voice]
    else:
        cmd += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100"]
    cmd += ["-filter_complex", f"[0:v]{SCALE}[v];[1:a]aresample=44100,apad[a]",
            "-map", "[v]", "-map", "[a]", "-t", f"{dur:.3f}"] + VIDEO_ENC + AUDIO_ENC + [out_mp4]
    run(cmd)


def srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


# ---------------------------------------------------------------- main
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Build a 30-second trailer from a script markdown.")
    ap.add_argument("--script", required=True, help="script markdown (see references/script-template.md)")
    ap.add_argument("--assets", default="assets", help="folder with shot1.png / shotN.mp4 / music.mp3 (default: assets)")
    ap.add_argument("--out", default="out", help="output folder (default: out)")
    ap.add_argument("--ffmpeg", default=None, help="path to ffmpeg.exe (default: PATH, then tools/ffmpeg/**/bin)")
    ap.add_argument("--voice-en", default="en-US-AriaNeural")
    ap.add_argument("--voice-zh", default="zh-TW-HsiaoChenNeural")
    args = ap.parse_args(argv)

    project = Path.cwd()
    out = Path(args.out)
    work = out / "work"
    work.mkdir(parents=True, exist_ok=True)
    assets = Path(args.assets)
    checks: list[tuple[str, bool]] = []
    notes: list[str] = []

    def finish() -> int:
        lines = [f"{t} {'OK' if ok else 'FAIL'}" for t, ok in checks] + notes
        (out / "check.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        say("\n".join(lines))
        all_ok = bool(checks) and all(ok for _, ok in checks)
        fails = [t for t, ok in checks if not ok]
        offline_only = (len(fails) == 1 and fails[0].startswith("audio=")
                        and any(n.startswith("voice: NONE") for n in notes))
        if all_ok:
            say("ALL OK")
            return 0
        if offline_only:
            # SKILL.md Step 3: the one allowed exception - no narration because the voice service could not be reached
            say("DONE WITHOUT NARRATION (offline): captions are burned in; hand it in and tell the captain there is no voice")
            return 0
        say("NOT DONE - read out/check.txt and tell the captain what failed")
        return 2

    # 0. tools
    try:
        ffmpeg, ffprobe = find_ffmpeg(args.ffmpeg, project)
    except ToolError as e:
        say(str(e))
        checks.append((f"tools=ffmpeg missing ({str(e).splitlines()[0]})", False))
        return finish()
    say(f"ffmpeg: {ffmpeg}")

    # 1. script
    try:
        sc = parse_script(Path(args.script))
    except ScriptError as e:
        say(str(e))
        checks.append((f"script={e}", False))
        return finish()
    shots = sc["shots"]
    say(f"script: {args.script} - {len(shots)} shot(s), title: {sc['title']}")
    for s in shots:
        if len(s["caption"].split()) > 15 and cjk_ratio(s["caption"]) < 0.3:
            notes.append(f"note: Shot {s['n']} caption has more than 15 words; the captain asked for 15 or fewer")

    # 2. narration
    voiced = 0
    offline_reason = ""
    for s in shots:
        if offline_reason:
            s["voice_file"] = None
            continue
        voice = args.voice_zh if cjk_ratio(s["voice"]) > 0.3 else args.voice_en
        mp3 = work / f"voice{s['n']}.mp3"
        ok, why = tts(s["voice"], voice, mp3)
        if ok:
            s["voice_file"] = mp3
            s["voice_sec"] = probe_duration(ffprobe, mp3)
            voiced += 1
            say(f"voice {s['n']}: {voice} {s['voice_sec']:.1f}s")
        else:
            s["voice_file"] = None
            offline_reason = why
            say(f"voice {s['n']}: no narration ({why})")
    if offline_reason:
        notes.append("voice: NONE (offline)")
        notes.append(f"voice-detail: {offline_reason.splitlines()[0][:160]}")
        if "403" in offline_reason:
            notes.append("voice-hint: a 403 usually means edge-tts is out of date - run: python -m pip install --user --upgrade edge-tts (Step 0), then run again")

    # 3. shot lengths: natural length first, then stretch evenly (up to 10 s each) until the whole trailer reaches 28 s
    for s in shots:
        if s.get("voice_file"):
            nat = max(s["voice_sec"] + VOICE_PAD, SHOT_MIN)
            if nat > SHOT_MAX:
                notes.append(f"note: Shot {s['n']} narration is {s['voice_sec']:.1f}s, longer than the 10-second cap; it is cut - shorten the voice line")
            s["dur"] = min(nat, SHOT_MAX)
        else:
            s["dur"] = OFFLINE_SHOT
    total = sum(s["dur"] for s in shots) + DISCLOSURE_SEC
    for _ in range(50):
        if total >= TARGET_LO - 0.01:
            break
        room = [s for s in shots if s["dur"] < SHOT_MAX - 0.001]
        if not room:
            break
        add = min((TARGET_LO - total) / len(room), min(SHOT_MAX - s["dur"] for s in room))
        for s in room:
            s["dur"] += add
        total = sum(s["dur"] for s in shots) + DISCLOSURE_SEC

    # 4. pictures + per-shot segments
    seg_files: list[Path] = []
    t_cursor = 0.0
    srt: list[str] = []
    for s in shots:
        n = s["n"]
        clip = resolve_asset(s.get("clip", ""), project, assets)
        image = resolve_asset(s.get("image", ""), project, assets)
        for key, got in (("clip", clip), ("image", image)):
            if s.get(key) and not got:
                notes.append(f"note: Shot {n} {key} '{s[key]}' not found; used a text card instead")
        if not clip and not image and not s.get("clip") and not s.get("image"):
            # nothing named in the script: use assets/shotN.mp4 or assets/shotN.png if the captain put one there
            for ext in (".mp4", ".png", ".jpg", ".jpeg"):
                cand = assets / f"shot{n}{ext}"
                if cand.exists():
                    if ext == ".mp4":
                        clip = cand
                    else:
                        image = cand
                    break
        if clip:
            visual, is_clip = clip, True
        else:
            visual, is_clip = work / f"frame{n}.png", False
            if image:
                frame_from_image(image, visual)
            else:
                frame_text_card(sc["title"], s["caption"], n, visual)
        seg = work / f"seg{n}.mp4"
        try:
            segment(ffmpeg, visual, is_clip, s.get("voice_file"), s["dur"], seg)
        except ToolError as e:
            say(str(e))
            checks.append((f"shot{n}=ffmpeg failed", False))
            return finish()
        seg_files.append(seg)
        srt.append(f"{len(srt) + 1}\n{srt_time(t_cursor + 0.1)} --> {srt_time(t_cursor + s['dur'] - 0.1)}\n{s['caption']}\n")
        t_cursor += s["dur"]
        say(f"shot {n}: {'clip' if is_clip else ('image' if image else 'text card')}, {s['dur']:.1f}s")

    # disclosure card
    dpng = work / "disclosure.png"
    frame_disclosure(sc["disclosure"], dpng)
    dseg = work / "seg_disclosure.mp4"
    try:
        segment(ffmpeg, dpng, False, None, DISCLOSURE_SEC, dseg)
    except ToolError as e:
        say(str(e))
        checks.append(("disclosure=ffmpeg failed", False))
        return finish()
    seg_files.append(dseg)

    # 5. subtitles file
    srt_path = out / "trailer.srt"
    srt_path.write_text("\n".join(srt), encoding="utf-8")

    # 6. concat, then burn subtitles (+ music) in one final pass
    lst = work / "concat.txt"
    lst.write_text("".join(f"file '{p.name}'\n" for p in seg_files), encoding="utf-8")
    joined = work / "joined.mp4"
    music = resolve_asset(sc["music"], project, assets) if sc["music"] else None
    if sc["music"] and not music:
        notes.append(f"note: music '{sc['music']}' not found; no music")
    if not music and (assets / "music.mp3").exists():
        music = assets / "music.mp3"
    final = out / "trailer.mp4"
    try:
        run([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst.name,
             "-c", "copy", joined.name], cwd=work)
        # run inside out/ so the subtitles filter only sees "trailer.srt" (no drive-letter escaping needed)
        cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", joined.resolve()]
        vf = f"[0:v]subtitles=trailer.srt:force_style='{SUB_STYLE}'[v]"
        if music:
            cmd += ["-stream_loop", "-1", "-i", music.resolve()]
            fc = vf + f";[1:a]volume={MUSIC_DB},aresample=44100[m];[0:a][m]amix=inputs=2:duration=first:normalize=0[a]"
            cmd += ["-filter_complex", fc, "-map", "[v]", "-map", "[a]"]
        else:
            cmd += ["-filter_complex", vf, "-map", "[v]", "-map", "0:a"]
        cmd += ["-t", f"{total:.3f}"] + VIDEO_ENC + AUDIO_ENC + ["-movflags", "+faststart", final.name]
        run(cmd, cwd=out)
    except ToolError as e:
        say(str(e))
        checks.append(("file=out/trailer.mp4 not written (ffmpeg failed)", False))
        return finish()

    # 7. check
    dur = probe_duration(ffprobe, final)
    streams = run([ffprobe, "-v", "error", "-show_entries", "stream=codec_type", "-of", "json", final]).stdout
    kinds = [s["codec_type"] for s in json.loads(streams)["streams"]]
    size = final.stat().st_size
    out_rel = Path(args.out).as_posix().rstrip("/")
    checks.append((f"duration={dur:.1f} (target {TARGET_LO:.0f}–{TARGET_HI:.0f})", TOL_LO <= dur <= TOL_HI))
    checks.append((f"shots={len(shots)}", len(shots) == 3))
    checks.append((f"captions={len(srt)} burned", len(srt) == len(shots) and srt_path.exists()))
    checks.append(("disclosure=yes", True))
    audio_desc = ("voice" if voiced else "none") + ("+music" if music else "")
    checks.append((f"audio={audio_desc}", voiced == len(shots) and "audio" in kinds))
    checks.append((f"file={out_rel}/trailer.mp4 {size}", size > 0 and "video" in kinds))
    return finish()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
