---
name: make-trailer
description: Build a 30-second trailer video (mp4) from a script markdown - three shots, burned-in captions, free text-to-speech narration, optional music and clips, and a closing AI-disclosure card. Use when asked for a trailer, teaser, 30-second video, or 預告片.
---

# make-trailer / 做一支 30 秒預告片

You read the script, run one Python script, read the check file, and report. You do not need to know ffmpeg. / 你讀腳本、跑一支程式、讀自檢檔、回報；不用懂 ffmpeg。

Everything below is relative to the project folder (the folder that holds `AGENTS.md`). Run commands from there. / 路徑都從專案資料夾（有 `AGENTS.md` 的那一層）算起，指令也在那裡跑。

## Step 0 · Tools: check, and install what is missing / 第 0 步・工具：先檢查，缺什麼裝什麼

Run these three checks: / 先跑這三個檢查：

```
ffmpeg -version
python --version
python -c "import edge_tts, PIL"
```

Then make sure the narration service really answers (an old edge-tts can import fine and still get a 403): / 再確認配音服務真的會回（舊版 edge-tts 匯入正常、連線卻被拒 403）：

```
python -c "import os; os.makedirs('out', exist_ok=True)"
python -m edge_tts --text hello --write-media out/tts-probe.mp3
```

If it prints an error that mentions `403`, or the mp3 it leaves behind is 0 bytes, upgrade it: `python -m pip install --user --upgrade edge-tts`, then run the probe again. / 看到 403、或留下的 mp3 是 0 bytes，就升級 edge-tts，再試一次。

If all checks succeed, go to Step 1. If something is missing, say in one line what you are about to install and from where, then install it. The captain asking for a trailer (or asking you to set up your tools) is the permission to install from the two sources below, and only from these two. / 都過就到第 1 步。缺了就先講一句「我要裝什麼、從哪裡裝」再裝。小隊長要預告片（或要你設定工具）＝同意你從下面兩個來源安裝，也只准從這兩個來源。

- **ffmpeg** (no admin rights needed): / **ffmpeg**（不用管理員）：
  1. `winget install --id Gyan.FFmpeg -e --accept-package-agreements --accept-source-agreements`
  2. If winget fails or is blocked: download `https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip` and unzip it into `tools/ffmpeg/` inside this project folder. The script looks for `tools/ffmpeg/**/bin/ffmpeg.exe` by itself. / winget 不行就下載上面那個 zip，解壓到專案夾的 `tools/ffmpeg/`；程式會自己找。
  3. A freshly installed ffmpeg is only on PATH in a **new** shell. If `ffmpeg -version` still fails after installing, pass the full path instead: `--ffmpeg "C:\path\to\ffmpeg.exe"` (winget puts it under `%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg...\bin\`). / 剛裝好的 ffmpeg 要新開的視窗才看得到；看不到就用 `--ffmpeg` 給完整路徑。
- **Python** (3.10 or newer): `winget install --id Python.Python.3.13 -e`, then `python -m pip install --user --upgrade edge-tts pillow`. A Python you just installed is not visible in the window you are already running in: use its full path for the commands above, `& "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"`（PowerShell 寫法）, or ask the captain to close this window and start it again. Full-path example: `& "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe" -m pip install --user --upgrade edge-tts pillow`, then the same prefix for `-c "import edge_tts, PIL"` and for `-m edge_tts --text hello --write-media out/tts-probe.mp3`. / Python 沒有就這樣裝，再裝（或升級）兩個套件。剛裝好的 Python 在你已經開著的視窗裡看不到：上面的指令改用完整路徑 `& "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"`（PowerShell 寫法），或請小隊長關掉視窗重開。
- **Never** download any other executable or installer. If the install fails, **stop and tell the captain** what failed and what you tried. The captain can still hand in the card and the script v2 for the same marks (the student page says so). / 其他任何執行檔都不下載；裝不了就停下來告訴小隊長、說你試了什麼。小隊長改交卡＋腳本 v2，同分。

## Step 1 · Input: the script / 第 1 步・輸入：腳本

One markdown file in the format of `.agents/skills/make-trailer/references/script-template.md`. Default path: `workspace/outbox/<date>-trailer-script-v2.md` (the version the leader has already checked). The captain may name another file. / 一份照 `.agents/skills/make-trailer/references/script-template.md` 格式寫的 markdown。預設用 `workspace/outbox/<日期>-trailer-script-v2.md`（領隊驗收過的那版）；小隊長可以指定別的檔。

Required: `title`, `disclosure`, and for each of the three shots `caption`, `voice`, `source`. `image`/`clip` and `music` are optional. / 必填：title、disclosure，每一鏡的 caption、voice、source；image／clip 與 music 可省略。

**If a field is missing, stop and ask the captain. Do not invent a fact, a caption, or a source.** / **缺欄位就停下來問小隊長，不准自己編事實、字幕或來源。**

## Step 2 · Run / 第 2 步・跑

```
python .agents/skills/make-trailer/scripts/make_trailer.py --script workspace/outbox/<date>-trailer-script-v2.md --assets assets --out out
```

Options: `--ffmpeg <path to ffmpeg.exe>` when ffmpeg is not on PATH; `--voice-en` / `--voice-zh` to pick another built-in edge-tts voice (defaults: `en-US-AriaNeural`, `zh-TW-HsiaoChenNeural`). The run usually takes under a minute (about 10–20 seconds when tested, voice included), at most three. / 選項：ffmpeg 不在 PATH 用 `--ffmpeg`；換內建語音用 `--voice-en`／`--voice-zh`。一次通常不到一分鐘（實測約 10–20 秒，含配音），最多三分鐘。

What it does: one picture (or text card) per shot, narration by edge-tts, captions burned in as subtitles, music under the voice if there is any, a 4-second AI-disclosure card at the end, then `out/trailer.mp4`, `out/trailer.srt`, `out/check.txt`. / 它做的事：每鏡一張圖（沒圖就文字卡）、edge-tts 配音、字幕燒進畫面、有音樂就墊在旁白下、片尾 4 秒 AI 揭露卡，產出三個檔。

## Step 3 · Check / 第 3 步・自檢

Read `out/check.txt`. The six check lines (`duration`, `shots`, `captions`, `disclosure`, `audio`, `file`) end with `OK` or `FAIL`; lines starting with `note:` or `voice` (`voice:`, `voice-detail:`, `voice-hint:`) are hints, not failures. **All six OK counts as done**, with one exception: if the only FAIL is the `audio` line and there is a `voice: NONE (offline)` line, the video can still be handed in; report plainly that it has no narration. / 讀 `out/check.txt`：六行檢查（duration、shots、captions、disclosure、audio、file）結尾是 OK 或 FAIL；`note:`、`voice` 開頭的（`voice:`、`voice-detail:`、`voice-hint:`）是提醒，不算失敗。**六行全 OK 才算完成**，唯一例外：只有 `audio` 那行 FAIL、而且有 `voice: NONE (offline)` 那行時，影片還是可以交，但要如實回報沒有配音。

Example of a good one: / 全過長這樣：

```
duration=28.2 (target 28–32) OK
shots=3 OK
captions=3 burned OK
disclosure=yes OK
audio=voice+music OK
file=out/trailer.mp4 1234567 OK
```

If a line says FAIL, read the message, fix only what the message names (for example a missing field in the script), and run Step 2 again - once. If it still fails, stop and report. A line `voice: NONE (offline)` means the text-to-speech service could not be reached: the video still has captions; report it as the one thing you could not do. / 有 FAIL 就看訊息、只修它點名的那件事、再跑一次；再失敗就停下來回報。看到 `voice: NONE (offline)`＝配音服務連不上，影片有字幕沒聲音，當作「做不到的事」回報。

## Step 4 · Report / 第 4 步・回報

Tell the captain, in this order: the path of the video, the full content of `check.txt`, and anything you could not do. / 依序告訴小隊長：影片路徑、check.txt 全文、做不到的事。

## Never / 不能做

- No voice cloning: built-in edge-tts voices only. / 不克隆聲音，只用 edge-tts 內建語音。
- No real faces in the pictures. / 圖裡不用真人臉。
- Do not change the captions or the sources - those belong to the captain. / 不改字幕與來源，那是小隊長的。
- Never write that the AI checked the facts. The disclosure line says the captain (the human) checked them; the AI only drafted. / 不准寫「事實由 AI 查核」：揭露那行寫「由我（小隊長）查核」，AI 只是起草。
- Do not upload or publish the video anywhere. / 不上傳、不公開。
- Do not download any executable other than the two sources in Step 0. / 不從第 0 步以外的來源下載執行檔。
