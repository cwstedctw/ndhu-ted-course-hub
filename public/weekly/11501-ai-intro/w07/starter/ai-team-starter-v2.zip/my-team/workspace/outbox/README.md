# outbox 📤 — finished work from the member / 隊員放「做好的成品」

Same file name as the task note, plus one handoff line at the top: what I did, what to watch, ready to use or not. The leader checks here before the captain accepts. Exception: a trailer script follows `.agents/skills/make-trailer/references/script-template.md` and puts its `HANDOFF:` line at the end. / 檔名對應任務紙條；檔頭留一行交接：做了什麼、哪裡要注意、能不能直接用。領隊在這裡驗收。例外：預告片腳本照範本寫，交接行 `HANDOFF:` 放檔尾。
