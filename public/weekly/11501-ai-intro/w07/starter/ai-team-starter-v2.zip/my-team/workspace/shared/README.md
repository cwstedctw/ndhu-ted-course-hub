# shared 📚 — source files both teammates read / 兩人都會讀的原始資料

The AIs only read here; their work goes into `../outbox/`. / AI 只讀這裡，成品放 `../outbox/`。

- `campus-picker.html`: the "What can I do between classes?" picker. Double-click it to play. / 「課間我想做什麼？」挑選器，雙擊就能玩。
- Want the trailer to be about your own work? Copy your file into this folder next to `campus-picker.html` (your Week 3 `v1.html`, your Week 6 guide `.md`). Do not rename it and do not overwrite the picker. Open the file first: no names, student IDs or photos inside. Nothing copied = the trailer is about the picker; same score. / 想讓預告片講你自己的作品：把檔案複製進這個資料夾，跟 `campus-picker.html` 並排（第 3 週的 `v1.html`、第 6 週的使用說明 .md）。不要改名、不要蓋掉挑選器。放進來前先打開看：裡面不能有姓名、學號、照片。什麼都不放＝預告片講挑選器，同分。
- `activities.json`: the 12 fictional activities the picker uses. / `activities.json`：挑選器用的 12 個虛構活動。
- Optional `log.md`: one line per thing the team learned about the captain, `- [YYYY-MM-DD] ...`. / 可選 `log.md`：學到小隊長的習慣就記一行。

All activities are fictional teaching examples. / 活動全部是虛構的教學範例。
