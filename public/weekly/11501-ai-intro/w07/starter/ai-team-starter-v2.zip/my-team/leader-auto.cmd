@echo off
rem English only on purpose: in one test cmd.exe broke Chinese lines in this UTF-8 batch file (2026-10-09).
chcp 65001 >nul
cd /d "%~dp0"
rem This folder goes first on PATH so the leader can run "opencode" (the member) from PowerShell (2026-10-17 r1).
set "PATH=%~dp0;%PATH%"
title Leader (auto relay) - my-team
if not exist "%~dp0opencode.exe" (
  echo.
  echo   opencode.exe is not in this folder yet.
  echo   Drag opencode.exe into this folder, next to AGENTS.md.
  echo   Then double-click leader-auto.cmd again.
  echo.
  echo   This folder: "%~dp0"
  echo.
  pause
  exit /b 1
)
rem Keep the window title (Leader / Member) so the two windows are easy to tell apart.
set OPENCODE_DISABLE_TERMINAL_TITLE=1
rem A fresh PC shows an Update Available box with Confirm selected; this keeps v1.18.35 (2026-10-17 r2).
set OPENCODE_DISABLE_AUTOUPDATE=1
echo   Auto relay: this window calls the member by itself. Do not press Tab.
"%~dp0opencode.exe" --agent leader
