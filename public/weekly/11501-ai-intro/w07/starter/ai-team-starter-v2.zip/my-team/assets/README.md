# assets - your pictures, music and clips / 你的素材放這裡

- Put `shot1.png`, `shot2.png`, `shot3.png` here (or `shotN.mp4` for a short clip), and `music.mp3` if you made music. / 把 `shot1.png`、`shot2.png`、`shot3.png`（短片用 `shotN.mp4`）放這裡；有做音樂就放 `music.mp3`。
- Nothing here? The trailer still builds: each shot becomes a text card. / 沒放也能跑：每一鏡會變成文字卡。
- No real faces and no copied pictures; write where every picture came from in the script. / 不用真人臉、不用抄來的圖；每張圖的來源寫進腳本。
