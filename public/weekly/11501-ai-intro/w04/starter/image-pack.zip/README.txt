﻿W4 圖片包（Teachable Machine 備援用）｜W4 image pack (backup for Teachable Machine)

三個資料夾＝三類，每類 24 張（編號 01–24）：
  red-circle      紅圓
  blue-square     藍方
  green-triangle  綠三角
test 資料夾：每類 2 張測試圖（轉角度、變小、偏色、加雜訊），拿來測，不要拿去訓練。
全部是 Python 程式畫的幾何圖形：沒有真實照片、沒有人、沒有臉。

沒攝影機的組：
1. 每類先上傳 12 張（01–12），其餘留著。先做兩類，有餘力再加第三類。
2. 測的時候用 test 資料夾的圖（Preview 能不能改用檔案要看當天介面，不行就看老師的模型）。
3. 動手 B：補上剩下的 12 張（13–24），這就是原因①「例子太少」的改法。

Three folders = three classes, 24 images each (numbered 01-24).
The test folder has 2 harder test images per class (turned, smaller, color-shifted, noisy). Use them to test, not to train.
All images are shapes drawn by a Python script: no real photos, no people, no faces.

Groups without a camera:
1. Upload 12 images per class first (01-12) and keep the rest. Start with two classes; add the third if you have time.
2. To test, use the images in the test folder (whether Preview can take a file depends on the screen that day; if not, watch the teacher's model).
3. Hands-on B: add the other 12 images (13-24). That is the fix for reason 1, "too few examples".
