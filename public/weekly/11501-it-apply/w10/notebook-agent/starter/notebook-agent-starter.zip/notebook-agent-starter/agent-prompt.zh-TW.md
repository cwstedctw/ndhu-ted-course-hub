請幫我在這台電腦設定並測試 Gemini Notebook API（https://notebook.googleapis.com/v1）。
官方文件：https://developers.google.com/notebook/docs/quickstart

【規則，全程遵守】
A. 先只給我「計畫」：你要裝什麼、會開幾次瀏覽器要我登入、哪一步要我自己到網頁上做、會在我的 Google 帳號裡建立什麼。我回「可以」之後才開始動手。
B. 每做完一步，把你實際看到的輸出貼給我看；失敗就把完整錯誤訊息給我，不要說「應該成功了」。
C. 需要我在瀏覽器登入或按「允許」的時候，停下來告訴我，等我說「好了」再繼續。我會用「個人 Gmail」，不是學校帳號。
D. 不要把存取權杖（access token）印在畫面上、寫進檔案或貼進對話；要用就放在變數裡。
E. 不要修改或刪除我原本的筆記本；只新增這次這一本。
F. 這台電腦是 Windows 就用 PowerShell；送 JSON 請用 Invoke-RestMethod，並把內容轉成 UTF-8 位元組再送（中文才不會變亂碼）。

【步驟】
1. 檢查 gcloud（Google Cloud CLI）有沒有裝：`gcloud --version`。
   沒有的話，Windows 用 `winget install --id Google.CloudSDK -e` 安裝，Mac 用 `brew install --cask gcloud-cli`；裝完重新找到 gcloud 再確認版本。
2. 登入 gcloud：`gcloud auth login`（會開瀏覽器，等我登入）。
3. 專案：用 `gcloud projects list --limit=10` 列出我有的專案讓我選。
   我沒有專案的話，幫我建一個：`gcloud projects create nb-加上六個隨機小寫英數字`（專案 ID 與名稱都不要有空格），再 `gcloud config set project 那個ID`。
4. 在那個專案啟用 API：`gcloud services enable notebook.googleapis.com --project=專案ID`。
5. 停下來，請我做一件只有我能做的事：照學生頁 3-4 在 Google Cloud Console 建一個「電腦版應用程式」OAuth 用戶端，
   把下載的 JSON 改名成 `client.json` 放進這個資料夾。等我說「放好了」再繼續。不要打開或印出這個檔的內容。
   （原因：官方文件那行不帶用戶端檔的登入，2026-11-10 實測會被 Google 顯示「系統已封鎖這個應用程式」。）
   接著取得帶 notebook 權限的本機憑證（會再開一次瀏覽器，等我按允許）：
   `gcloud auth application-default login --client-id-file=client.json --scopes="https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/notebook"`
6. 取權杖放進變數（不要印出來）：`gcloud auth application-default print-access-token`。
7. 驗證：帶兩個標頭 `Authorization: Bearer 權杖` 與 `x-goog-user-project: 專案ID`，
   GET https://notebook.googleapis.com/v1/notebooks ，告訴我 HTTP 狀態與看到幾本筆記本（只講數量）。
8. 建一本新筆記本：POST https://notebook.googleapis.com/v1/notebooks ，內容 `{"displayName":"W10-agent-空氣品質"}`。
9. 把下面每個來源加進這本筆記本：POST https://notebook.googleapis.com/v1/{筆記本的 name}/sources
   - 網頁：內容 `{"webContent":{"url":"網址"}}`
   - 文字檔：讀檔後內容 `{"displayName":"我的筆記","mimeType":"text/markdown","textContent":{"content":"檔案全文"}}`
10. 每 3 秒查一次 GET https://notebook.googleapis.com/v1/{筆記本的 name}/sources ，
    直到每個來源的 state 都是 ACTIVE 或 FAILED。
11. 最後給我一張表：每個來源的名稱、state；FAILED 的附上 error 訊息。再給我筆記本的 name，我要自己到 https://notebook.google.com 打開它檢查。

【來源】
- https://zh.wikipedia.org/zh-tw/%E7%A9%BA%E6%B0%A3%E5%93%81%E8%B3%AA%E6%8C%87%E6%A8%99
- https://airtw.moenv.gov.tw/CHT/Information/Standard/AirQualityIndicator.aspx
- https://zh.wikipedia.org/zh-tw/%E6%87%B8%E6%B5%AE%E7%B2%92%E5%AD%90
- 這個資料夾裡的 my-notes.md（如果有）
