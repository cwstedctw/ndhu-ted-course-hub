# nb.ps1 - tiny helper for the Gemini Notebook API (public preview)
# Works on Windows PowerShell 5.1 and PowerShell 7. ASCII only on purpose.
# Docs: https://developers.google.com/notebook/docs
#
#   .\nb.ps1 check                         -> is gcloud ready? can we list notebooks?
#   .\nb.ps1 list                          -> list my notebooks
#   .\nb.ps1 new "W10 my topic"            -> create a notebook, prints notebooks/<id>
#   .\nb.ps1 add notebooks/<id> https://...  ["display name"]   -> add a web page / YouTube source
#   .\nb.ps1 addtext notebooks/<id> notes.md ["display name"]   -> add a UTF-8 text / Markdown file
#   .\nb.ps1 sources notebooks/<id>        -> list sources and their state
#   .\nb.ps1 wait notebooks/<id>           -> poll until no source is PROCESSING
#
# The access token is never printed and never written to disk by this script.

param(
  [Parameter(Position=0)][string]$Cmd = "check",
  [Parameter(Position=1)][string]$A1,
  [Parameter(Position=2)][string]$A2,
  [Parameter(Position=3)][string]$A3
)

$ErrorActionPreference = "Stop"
$Root = "https://notebook.googleapis.com/v1"

function Get-Gcloud {
  $g = Get-Command gcloud.cmd -ErrorAction SilentlyContinue
  if (-not $g) { $g = Get-Command gcloud -ErrorAction SilentlyContinue }
  if (-not $g) { throw "gcloud not found. Install Google Cloud CLI first, then open a NEW PowerShell window." }
  return $g.Source
}

# Run gcloud and return only its stdout lines.
# (In PS 5.1, stderr from a native command becomes an error record when
#  ErrorActionPreference is Stop, so we relax it just for this call.)
function Invoke-Gcloud {
  $g = Get-Gcloud
  $old = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    $out = & $g @args 2>&1 | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] }
  } finally { $ErrorActionPreference = $old }
  return @($out | ForEach-Object { "$_".Trim() } | Where-Object { $_ })
}

function Get-ProjectId {
  if ($env:NB_PROJECT) { return $env:NB_PROJECT }
  $p = Invoke-Gcloud config get-value project | Select-Object -Last 1
  if (-not $p -or $p -match "unset") { throw "No project. Run: gcloud config set project YOUR_PROJECT_ID  (or set `$env:NB_PROJECT)" }
  return $p
}

function Get-Token {
  $t = Invoke-Gcloud auth application-default print-access-token | Select-Object -Last 1
  if (-not $t -or $t.Length -lt 20 -or $t -match "\s") {
    throw "No token. Run: gcloud auth application-default login --scopes=https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/notebook"
  }
  return $t.Trim()
}

function Invoke-Nb([string]$Method, [string]$Path, $Body) {
  $headers = @{ "Authorization" = "Bearer $(Get-Token)"; "x-goog-user-project" = (Get-ProjectId) }
  $uri = "$Root/$Path"
  try {
    if ($null -ne $Body) {
      $json  = $Body | ConvertTo-Json -Depth 6 -Compress
      $bytes = [Text.Encoding]::UTF8.GetBytes($json)   # PS 5.1 would send Latin-1 otherwise
      return Invoke-RestMethod -Method $Method -Uri $uri -Headers $headers -Body $bytes -ContentType "application/json; charset=utf-8"
    }
    return Invoke-RestMethod -Method $Method -Uri $uri -Headers $headers
  } catch {
    $msg = $_.ErrorDetails.Message
    if (-not $msg) { $msg = $_.Exception.Message }
    Write-Host "API ERROR ($Method $Path):" -ForegroundColor Red
    Write-Host $msg
    exit 1
  }
}

function Show-Sources([string]$Nb) {
  $r = Invoke-Nb GET "$Nb/sources?pageSize=100" $null
  if (-not $r.sources) { Write-Host "(no sources yet)"; return @() }
  $r.sources | ForEach-Object { "{0,-11} {1}  <{2}>" -f $_.state, $_.displayName, $_.name } | Write-Host
  return $r.sources
}

switch ($Cmd.ToLower()) {
  "check" {
    Write-Host ("gcloud : " + (Get-Gcloud))
    Write-Host ("project: " + (Get-ProjectId))
    $null = Get-Token
    Write-Host "token  : ok (not shown)"
    $r = Invoke-Nb GET "notebooks?pageSize=5" $null
    $n = 0; if ($r.notebooks) { $n = @($r.notebooks).Count }
    Write-Host "API    : ok, first page has $n notebook(s)"
  }
  "list" {
    $r = Invoke-Nb GET "notebooks?pageSize=100" $null
    if (-not $r.notebooks) { Write-Host "(no notebooks)"; break }
    $r.notebooks | ForEach-Object { "{0}  {1}  {2}" -f $_.name, $_.createTime, $_.displayName } | Write-Host
  }
  "new" {
    if (-not $A1) { throw 'usage: .\nb.ps1 new "title"' }
    $r = Invoke-Nb POST "notebooks" @{ displayName = $A1 }
    Write-Host "created: $($r.name)"
    Write-Host "title  : $($r.displayName)"
  }
  "add" {
    if (-not $A1 -or -not $A2) { throw 'usage: .\nb.ps1 add notebooks/<id> https://... ["display name"]' }
    $src = @{ webContent = @{ url = $A2 } }
    if ($A3) { $src.displayName = $A3 }
    $r = Invoke-Nb POST "$A1/sources" $src
    Write-Host "added  : $($r.name)  (processing; run: wait)"
  }
  "addtext" {
    if (-not $A1 -or -not $A2) { throw 'usage: .\nb.ps1 addtext notebooks/<id> file.md ["display name"]' }
    $text = [IO.File]::ReadAllText((Resolve-Path $A2), [Text.Encoding]::UTF8)
    $name = $A3; if (-not $name) { $name = [IO.Path]::GetFileName($A2) }
    $mime = "text/plain"; if ($A2 -match "\.md$") { $mime = "text/markdown" }
    $r = Invoke-Nb POST "$A1/sources" @{ displayName = $name; mimeType = $mime; textContent = @{ content = $text } }
    Write-Host "added  : $($r.name)  (processing; run: wait)"
  }
  "sources" {
    if (-not $A1) { throw 'usage: .\nb.ps1 sources notebooks/<id>' }
    $null = Show-Sources $A1
  }
  "wait" {
    if (-not $A1) { throw 'usage: .\nb.ps1 wait notebooks/<id>' }
    for ($i = 0; $i -lt 60; $i++) {
      $s = Show-Sources $A1
      $busy = @($s | Where-Object { $_.state -eq "PROCESSING" }).Count
      if ($busy -eq 0) { Write-Host "done: nothing is PROCESSING."; break }
      Write-Host "... $busy still PROCESSING, checking again in 3 s"
      Start-Sleep -Seconds 3
    }
  }
  default { Write-Host "unknown command: $Cmd  (check | list | new | add | addtext | sources | wait)" }
}
