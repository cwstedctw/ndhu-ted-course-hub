# W12 起始檔：UNO Q 大腦 × ESP32 手腳

| 檔 | 在哪跑 | 做什麼 |
|---|---|---|
| `brain.py` | UNO Q（電腦也可以） | 主程式：每秒讀 ESP32 → 用 `rules.py` 想一想 → 叫 ESP32 做事 → 寫 CSV、量延遲 |
| `rules.py` | — | **你要改的那支**：溫度門檻、夜燈、A 鍵要做什麼 |
| `link_wifi.py` | — | WiFi 這條線：HTTP 問答（只用 Python 內建模組） |
| `link_ble.py` | — | 藍牙這條線：bleak 寫入／通知；另有 `SimBleLink` 給沒藍牙時模擬 |
| `fake_esp32.py` | UNO Q 或電腦 | 假的 ESP32：網址跟創客課第 10 課一模一樣，瀏覽器看得到虛擬板子 |

ESP32 那邊**不用寫程式**：跑創客課 repo 的 `d10_wifi_web.py`（WiFi）或 `d11_ble_remote.py`（藍牙）。

## 先用假的 ESP32 練（不用任何板子）

```
python3 fake_esp32.py
```
另開一個終端機：
```
python3 brain.py --link wifi --esp 127.0.0.1:8090
python3 brain.py --link ble-sim --esp 127.0.0.1:8090
```
瀏覽器開 `http://127.0.0.1:8090`（在 UNO Q 上跑的話，電腦開 `http://192.168.7.2:8090`）拉溫度、光線、旋鈕，看燈怎麼變。
假板子跑在**別台電腦**時，`--esp` 寫那台電腦的 IP 加 `:8090`，不是 `127.0.0.1`。

## 接真的 ESP32：WiFi

1. ESP32 跑 `d10_wifi_web.py`，OLED 會顯示 `maker-XXXX`、`pw makerXXXX`、`192.168.4.1`。
2. UNO Q 連上 ESP32 的基地台（UNO Q 的 WiFi 會暫時離開原本的網路）：
   ```
   nmcli device wifi list
   sudo nmcli --ask device wifi connect maker-XXXX
   ```
3. `python3 brain.py --link wifi --esp 192.168.4.1`

## 接真的 ESP32：藍牙

1. ESP32 跑 `d11_ble_remote.py`（W12 選單：按住 A 再按 EN，看到 OLED 顯示 `BLE` 才放開），OLED 第二行是 `maker-XXXX`。
2. UNO Q 裝 bleak（要網路，所以在連 ESP32 基地台**之前**先裝好；不要 `sudo pip install`）：
   ```
   python3 -m venv --system-site-packages ~/w12env
   ~/w12env/bin/pip install bleak
   ```
3. `~/w12env/bin/python brain.py --link ble --name maker-XXXX`

## 停下來

`Ctrl+C`：ESP32 的燈會全關，畫面印出「讀一次感測值來回」的中位數、最快、最慢。紀錄在 `log_<連法>_<時間>.csv`。

小提醒：ESP32 的感測值大約每 2 秒才更新一次，每秒問會連續拿到同一筆；手機同時開著 d10 網頁會跟大腦搶連線，想同時開就加 `--period 2`。
