# ============================================
# link_wifi.py — WiFi 這條線：UNO Q 用 HTTP 跟 ESP32 講話
# ============================================
# ESP32 跑的是創客課第 10 課 d10_wifi_web.py（不用改），它開了這幾個網址：
#   GET /api/status                    → 回一段 JSON：溫度、濕度、光線、旋鈕、三顆燈的狀態
#   GET /api/led?name=red&on=1         → 紅燈開（name 可以是 red／yellow／blue）
#   GET /api/rgb?r=255&g=0&b=0         → 彩色燈
#   GET /api/beep                      → 嗶一聲
#   GET /api/off                       → 全部關
# ⚠️ d10 裡第三顆燈的名字叫 blue，但它在板子上其實是「綠燈」（GPIO 13）。
#
# 只用 Python 內建的 urllib，UNO Q 上不用另外裝套件。
# ============================================

import json
import time
import urllib.request

LED_NAME = {"red": "red", "yellow": "yellow", "green": "blue"}   # 我們說 green，d10 叫它 blue


class WifiLink:
    kind = "wifi"

    def __init__(self, host, timeout=3.0):
        self.base = "http://" + host
        self.timeout = timeout
        self.last_rtt_ms = None

    def _get(self, path):
        t0 = time.perf_counter()
        with urllib.request.urlopen(self.base + path, timeout=self.timeout) as r:
            body = r.read()
        self.last_rtt_ms = (time.perf_counter() - t0) * 1000
        return json.loads(body)

    async def connect(self):
        st = self._get("/api/status")          # 先問一次，確定找得到板子
        return "WiFi 連上 {}（回應 {:.0f} ms）".format(self.base, self.last_rtt_ms)

    async def read(self):
        st = self._get("/api/status")
        sensors = {
            "temp": st.get("temp"),
            "hum": st.get("hum"),
            "light": st.get("light"),
            "knob": st.get("knob"),
            "button": None,                    # d10 的 JSON 裡沒有按鈕，WiFi 這條線讀不到
        }
        return sensors, self.last_rtt_ms

    async def send(self, action, value=None):
        """action：'red'／'yellow'／'green'（value＝True/False）、'rgb'（value＝(r,g,b)）、'beep'、'off'"""
        if action in LED_NAME:
            self._get("/api/led?name={}&on={}".format(LED_NAME[action], 1 if value else 0))
        elif action == "rgb":
            r, g, b = value
            self._get("/api/rgb?r={}&g={}&b={}".format(r, g, b))
        elif action == "beep":
            self._get("/api/beep")
        elif action == "off":
            self._get("/api/off")

    async def close(self):
        pass
